import {env} from 'cloudflare:workers';
export function db(){if(!env.DB)throw new Error('資料儲存暫時無法使用');return env.DB;}
export async function read(key:string){const row=await db().prepare('SELECT value, updated FROM store WHERE key=?').bind(key).first<{value:string,updated:number}>();return row?{data:JSON.parse(row.value),updated:row.updated}:null;}
export async function save(key:string,data:unknown){await db().prepare('INSERT INTO store (key,value,updated) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated').bind(key,JSON.stringify(data),Date.now()).run();}
