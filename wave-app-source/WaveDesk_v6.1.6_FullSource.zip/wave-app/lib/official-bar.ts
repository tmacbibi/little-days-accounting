// Append only a contiguous, official OHLC session with verified corporate actions.
// A gap, price discontinuity or new rights/dividend event requires the full history fetch.
export function appendOfficialBar(cached:any,q:any,actions:any){
 const last=cached?.bars?.at(-1);
 if(!last||!q||!['TW','TWO'].includes(q.market)||q.date<=last.date||!actions?.verified||actions.asOf<q.date||!Array.isArray(actions.events))return null;
 const expected=new Date(last.date+'T00:00:00Z');do{expected.setUTCDate(expected.getUTCDate()+1)}while([0,6].includes(expected.getUTCDay()));
 if(expected.toISOString().slice(0,10)!==q.date)return null;
 if(actions.events.some((e:any)=>e.code===q.code&&e.date>last.date&&e.date<=q.date))return null;
 if(![q.open,q.high,q.low,q.close,q.change,q.volume].every(Number.isFinite)||q.low<=0||q.volume<0||q.high<Math.max(q.open,q.close)||q.low>Math.min(q.open,q.close))return null;
 if(Math.abs((q.close-q.change)/last.close-1)>0.0015)return null;
 const bar={date:q.date,open:q.open,high:q.high,low:q.low,close:q.close,volume:q.volume};
 const {warning,...clean}=cached;
 const from=new Date(q.date+'T00:00:00Z');from.setUTCMonth(from.getUTCMonth()-6);from.setUTCDate(from.getUTCDate()-7);const cutoff=from.toISOString().slice(0,10);
 return {...clean,bars:[...cached.bars,bar].filter(b=>b.date>=cutoff),source:cached.source.replace(/；末日補齊(?:證交所|櫃買中心)官方OHLC/g,'')+`；末日補齊${q.market==='TW'?'證交所':'櫃買中心'}官方OHLC`,fetched:new Date().toISOString()};
}
