import companies from './initial-sectors.json';
// Exchange company rosters identify the ordinary-share universe. A four-digit
// code alone is insufficient: several ETFs have four digits as well.
export function isOrdinary(q:{code:string,market:string}){
 return /^[1-9]\d{3}$/.test(q.code)&&Object.hasOwn(companies,`${q.market}:${q.code}`);
}
