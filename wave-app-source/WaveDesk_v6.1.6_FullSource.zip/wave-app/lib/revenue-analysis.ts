export type RevenueRow={code:string,name?:string,month:string,value:number,lastYear:number|null,yoy:number|null,mom:number|null,note?:string,source:string};
export function revenueSummary(input:RevenueRow[],asOf:string,fetched:string){
 const rows=[...new Map(input.filter(r=>r.month<asOf.slice(0,7)&&Number.isFinite(r.value)&&r.value>=0).map(r=>[r.month,r])).values()].sort((a,b)=>a.month.localeCompare(b.month));
 const latest=rows.at(-1);if(!latest)return {status:'資料不足',reason:'尚無可核對的月營收',rows:[],asOf,fetched,weighted:false};
 const monthIndex=(s:string)=>Number(s.slice(0,4))*12+Number(s.slice(5,7));
 const consecutive=(a:RevenueRow[])=>a.every((r,i)=>!i||monthIndex(r.month)-monthIndex(a[i-1].month)===1);
 const rolling=(a:RevenueRow[])=>a.length===3&&consecutive(a)&&a.every(r=>r.lastYear!==null&&r.lastYear>0)?(a.reduce((s,r)=>s+r.value,0)/a.reduce((s,r)=>s+r.lastYear!,0)-1)*100:null;
 const last3=rows.slice(-3),previous3=rows.slice(-6,-3),rolling3=rolling(last3),previousRolling3=rows.length>=6&&consecutive(rows.slice(-6))?rolling(previous3):null;
 const stale=monthIndex(asOf.slice(0,7))-monthIndex(latest.month)>2;
 const positive3=last3.length===3&&consecutive(last3)&&last3.every(r=>r.yoy!==null&&r.yoy>0);
 const status=stale?'資料待更新':rolling3===null?'資料不足':positive3?'營收支持':rolling3<0&&latest.yoy!==null&&latest.yoy<0&&previousRolling3!==null&&rolling3<previousRolling3?'營收轉弱':'改善待確認';
 const reason=stale?'營收月份較舊，不據此判斷目前營運':rolling3===null?'缺少連續三個月或去年同期資料':positive3?'近三個月營收均較去年同月增加，支持技術面觀察':status==='營收轉弱'?'近三個月合計營收年減，且較前一個三月區間轉弱':'年增與持續性尚未一致，需配合季節性及產業判讀';
 return {status,reason,latest,rolling3,previousRolling3,positive3,rows:rows.slice(-6),asOf,fetched,weighted:false,unit:'新臺幣仟元',note:'營收不是獲利；未核對季度毛利率、EPS及一次性因素。不改變波段潛力、進場適合度或技術買點。'};
}
