// Dates come from actual exchange responses; weekends and holidays need no guessed calendar.
export function updateStatus(queue:any[],hist:Record<string,any>,m:any,feeds:any,completion:any,now=Date.now()){
 const verifiedMarkets=Object.fromEntries(['TW','TWO'].map(k=>[k,!!m.sessionVerified&&!!m.confirmed?.[k]&&m.quotes.some((q:any)=>q.market===k&&q.date===m.expectedSession)]));
 queue=queue.filter(q=>verifiedMarkets[q.market]);
 const inputKey=queue.map(q=>`${q.market}:${q.code}:${q.date}:${q.close}:${q.volume}`).join('|');
 const missing=queue.filter(q=>!hist[`${q.market}:${q.code}`]?.bars?.length||hist[`${q.market}:${q.code}`].bars.at(-1).date<q.date).map(q=>({code:q.code,market:q.market}));
 const dates=Object.fromEntries(['TW','TWO'].map(k=>[k,m.quotes.filter((q:any)=>q.market===k).map((q:any)=>q.date).sort().at(-1)||null]));
 const feedsNeeded=['TW','TWO'].some(k=>verifiedMarkets[k]&&dates[k]&&(!feeds.risk.markets[k]?.verified||feeds.risk.markets[k].asOf<dates[k]||!feeds.actions.markets[k]?.verified||feeds.actions.markets[k].asOf<dates[k]));
 const marketReady=!!m.sessionVerified&&['TW','TWO'].every(k=>m.confirmed?.[k]&&dates[k]===m.expectedSession);
 // The check route rebuilds the report from the current market before returning.
 // A different device's tracked list must not invalidate already aligned daily bars.
 const availableComplete=!!queue.length&&!missing.length&&!feedsNeeded;
 const complete=marketReady&&availableComplete;
 return {verifiedMarkets,availableComplete,inputKey,missing,marketDates:dates,feedsNeeded,complete,total:queue.length,marketReady,expectedSession:m.expectedSession||null,sourceMessages:m.messages||[]};
}
