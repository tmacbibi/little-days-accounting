import type {Bar,Quote} from './analysis';
import {priceUp,priceDown,tick as priceTick} from './pricing';
export const RULE_VERSION='buy-points-6.0';
export const FRESH_SIGNAL_SESSIONS=1;
export type RiskRegistry={asOf:string,fetched:string,markets:Record<string,{verified:boolean,asOf:string,attention:string[],warning:string[],disposal:{code:string,start:string,end:string}[],sources:string[],error?:string}>};
export type Context={quote?:Quote,benchmark?:{date:string,close:number}[],sector?:string,risk?:RiskRegistry,source?:string,adjusted?:boolean,eventsChecked?:boolean,events?:{date:string,cash:number,split?:number}[]};
const clamp=(n:number,a=0,b=100)=>Math.max(a,Math.min(b,n));
const round=(n:number,d=2)=>Number(n.toFixed(d));
const mean=(v:number[])=>v.length?v.reduce((s,x)=>s+x,0)/v.length:0;
const tick=(v:number)=>v<10?.01:v<50?.05:v<100?.1:v<500?.5:v<1000?1:5;


export function riskStatus(code:string,market:string,date:string,risk?:RiskRegistry){const r=risk?.markets[market];if(!r?.verified||r.asOf<date)return {level:'unknown',label:'公告尚未核對',blocked:true,reason:'公告資料缺漏或日期早於K線，暫不列優先名單'};const disposal=r.disposal.find(d=>d.code===code&&d.end>=date);if(disposal)return {level:'disposal',label:disposal.start>date?'已公告即將處置':'處置中',blocked:true,reason:`處置期間 ${disposal.start}～${disposal.end}`};if(r.warning.includes(code))return {level:'warning',label:'接近處置門檻',blocked:true,reason:'列入官方注意累計次數預警名單'};if(r.attention.includes(code))return {level:'attention',label:'當日注意股票',blocked:true,reason:'依你的偏好，當日注意股票暫不列優先名單'};return {level:'clear',label:'公告核對通過',blocked:false,reason:'目前未列入已核對的注意、預警與處置名單；不能保證未來不會被處置'};}

// Price structure is a declared range proxy; every window ends on the decision day.
export function research(input:Bar[],c:Context={}):any {
 const b=input.filter(x=>[x.open,x.high,x.low,x.close,x.volume].every(Number.isFinite)&&Math.min(x.open,x.low,x.close)>0&&x.high>=Math.max(x.open,x.close,x.low)&&x.low<=Math.min(x.open,x.close)&&x.volume>=0).slice().sort((a,z)=>a.date.localeCompare(z.date));
 const n=b.length,last=b.at(-1),date=last?.date||'',code=c.quote?.code||'',market=c.quote?.market||'TW',sector=c.sector||'未分類',risk=riskStatus(code,market,date,c.risk);
 const excluded=sector==='金融保險'||['2002','1101'].includes(code);
 if(n<65||!last)return {ready:false,date,count:n,risk,excluded,bucket:'other',reason:'至少需要65個交易日，暫不評分',stage:'資料待確認'};
 const avg=(period:number,end:number)=>mean(b.slice(end-period,end).map(x=>x.close));
 const averages=b.map((_,i)=>({m5:i>=4?avg(5,i+1):NaN,m10:i>=9?avg(10,i+1):NaN,m20:i>=19?avg(20,i+1):NaN}));
 const spread=(i:number)=>{const a=averages[i];return (Math.max(a.m5,a.m10,a.m20)-Math.min(a.m5,a.m10,a.m20))/a.m20};
 const cross=(i:number)=>{const signs:Record<string,number>={};for(let j=Math.max(20,i-31);j<=i;j++){const a=averages[j];if(j<i&&j>=i-30&&spread(j)<1e-8)return true;for(const [u,v] of [['m5','m10'],['m5','m20'],['m10','m20']] as const){const sign=Math.sign(a[u]-a[v]),key=u+v;if(sign&&signs[key]&&sign!==signs[key]&&j>=i-30)return true;if(sign)signs[key]=sign}}return false};
 const shape=(end:number)=>{const earlier=b.slice(end-30,end-15),recent=b.slice(end-15,end);const h1=Math.max(...earlier.map(x=>x.high)),h2=Math.max(...recent.map(x=>x.high)),l1=Math.min(...earlier.map(x=>x.low)),l2=Math.min(...recent.map(x=>x.low));return {h1,h2,l1,l2,higher:h2>h1+1e-5&&l2>l1+1e-5}};
 const features=(i:number)=>{const v=b[i],prev=b[i-1],top=Math.max(...b.slice(i-10,i).map(x=>x.high)),structure=shape(i),ratio=prev.volume>0?v.volume/prev.volume:0;return {top,structure,ratio,lots:v.volume/1000,squeeze:spread(i-1)<=.03,interweave:cross(i),red:v.close>v.open+1e-5,breakout:v.close>top+Math.max(1e-5,v.close*1e-6),volume:ratio>=2&&v.volume>=3000000,near:v.close<=top*1.05+1e-5}};
 const isSignal=(f:ReturnType<typeof features>)=>f.squeeze&&f.interweave&&f.structure.higher&&f.red&&f.breakout&&f.volume&&f.near;
 let episode:{index:number,low:number,high:number,top:number,type:string,evidence:string}|null=null;
 const classify=(i:number)=>{const prior=b.slice(i-20,i),gain=(prior.at(-1)!.close/prior[0].close-1)*100;const bull=averages.slice(i-20,i).filter(a=>a.m5>a.m10&&a.m10>a.m20).length;const second=gain>=10&&bull>=5;return {type:second?'上升途中整理再突破':'糾結後初次突破',evidence:`型態初判：突破前20日漲幅${round(gain)}%，其中${bull}日為五＞十＞二十日線。前段漲幅≥10%且多排≥5日標示整理再突破；僅分類，不影響買點資格。`}};
 for(let i=60;i<n;i++) {if(episode){if(b[i].close<averages[i].m10-1e-5||b[i].close<episode.low-1e-5)episode=null;continue}const f=features(i);if(isSignal(f)){const type=classify(i);episode={index:i,low:b[i].low,high:b[i].high,top:f.top,...type}}}
 const f=features(n-1),now=averages[n-1],ma5=now.m5,ma10=now.m10,ma20=now.m20,ma60=avg(60,n),prev=b[n-2];
 const signalAge=episode?n-1-episode.index:null,technical=episode?.index===n-1;
 const currentShape=shape(n),watch=!episode&&spread(n-1)<=.03&&cross(n-1)&&currentShape.higher;
 const stage=technical?'買點成立':episode?'已突破，等待機會':watch?'接近買點':'暫無買點';
 const bucket=technical?'confirmed':episode?'extended':watch?'watch':'other';
 const triggerBase=episode?.top??Math.max(...b.slice(-10).map(x=>x.high));
 const trigger=priceUp(triggerBase+priceTick(triggerBase),true),referenceHigh=priceDown(triggerBase*1.05);
 const signalLow=episode?.low??null,signalDate=episode?b[episode.index].date:null;
 const stop=signalLow===null?null:Math.max(ma10,signalLow),distance=(v:number|null)=>v===null?null:round((last.close-v)/last.close*100);
 const bias5=(last.close/ma5-1)*100,aboveBreakout=(last.close/triggerBase-1)*100,defenseDistance=distance(stop);
 const quality=c.adjusted?'已還原權息':c.eventsChecked?'已核對權息':'權息待核對';
 const actionsClear=c.eventsChecked===true&&c.adjusted===true,dataMismatch=!!c.quote&&(c.quote.date!==date||Math.abs(c.quote.close-last.close)>Math.max(priceTick(last.close),last.close*.005));
 const abnormalGap=b.slice(-20).some((x,i,a)=>i>0&&Math.abs(x.open/a[i-1].close-1)>.25);
 const blockers=[...(excluded?['依偏好排除金融股／中鋼／台泥']:[]),...(risk.blocked?[risk.reason]:[]),...(dataMismatch?['行情與日K日期或價格尚未對齊']:[]),...(!actionsClear?['權息資料尚未完成核對']:[]),...(abnormalGap?['價格有異常跳動，先核對公司事件']:[])];
 const actionable=blockers.length===0,priority=technical&&actionable;
 const strategy=episode?.type??(watch?classify(n-1).type:'尚無買點型態');
 const structure=episode?features(episode.index).structure:currentShape;
 const slope20=(ma20/avg(20,n-5)-1)*100;
 const bull=ma5>ma10&&ma10>ma20;
 const signalBar=episode?b[episode.index]:last,signalPrev=episode?b[episode.index-1]:prev;
 const signalRatio=signalPrev.volume?signalBar.volume/signalPrev.volume:0;
 const closePos=last.high>last.low?(last.close-last.low)/(last.high-last.low):.5;
 const potentialParts=[{name:'均線靠近與交錯',score:(episode||watch?25:spread(n-1)<=.03?12:0),max:25,note:'三條短均線差距不超過月線3%；不要求最短盤整日數'},
 {name:'頭頭高、底底高',score:structure.higher?25:0,max:25,note:`前後各15日高點${round(structure.h1)}→${round(structure.h2)}，低點${round(structure.l1)}→${round(structure.l2)}；區間近似，不等同人工轉折`},
 {name:'突破量價',score:episode?25:f.volume?12:0,max:25,note:'紅K突破前10日高點、前日量兩倍且至少3000張'},
 {name:'趨勢延續',score:(slope20>0?10:0)+(bull?10:0)+(ma60<Math.min(ma5,ma10,ma20)?5:0),max:25,note:'月線上彎、短均線多排與季線在下加分，季線不是必要門檻'}];
 const riskScore=defenseDistance===null?0:clamp(30-defenseDistance*3,0,30);
 const entryParts=[{name:'當日量價確認',score:technical?40:watch?10:episode?15:0,max:40,note:'只有當天符合完整突破條件才取得40分；過去訊號不是今天買點'},
 {name:'距離防守點',score:round(riskScore),max:30,note:stop===null?'尚無突破K低點，不先捏造停損':`距兩防守點較高者${defenseDistance}%；不保證成交損失上限`},
 {name:'追高程度',score:round(clamp(20-Math.max(0,bias5-2)*2,0,20)),max:20,note:`距五日線${round(bias5)}%；只提醒與評分，不硬性剔除`},
 {name:'收盤位置',score:round(closePos*10),max:10,note:'收盤越靠近當日高點，確認程度越高'}];
 const potential=round(potentialParts.reduce((s,p)=>s+p.score,0),0),rawEntry=round(entryParts.reduce((s,p)=>s+p.score,0),0),entry=actionable?rawEntry:0;
 const ranking=entry*1000+potential;
 const upper=b.slice(-120,-1).filter((x,i,a)=>x.high>last.close&&i>=2&&i<a.length-2&&a.slice(i-2,i+3).every(v=>v.high<=x.high)).sort((a,z)=>a.high-z.high);
 const resistance=upper[0]?{type:'已確認歷史高點',value:upper[0].high,date:upper[0].date,note:'上方第一壓力參考，非保證到價或強制停利'}:null;
 const decision=excluded?'排除':!actionable?'資料／公告待確認':technical?'買點成立，評估價格風險':watch?'先鎖股，等待帶量突破':episode?'已有漲幅，等待新買點':'等待新的整理';
 const technicalReason=`紅K突破前10日高點${round(f.top)}；成交${round(f.lots,0).toLocaleString('zh-TW')}張、前日${round(f.ratio)}倍。`;
 const warning=defenseDistance!==null&&defenseDistance>5?`距較近防守點仍有${defenseDistance}%，看錯時風險偏大。`:'';
 const reason=blockers.length?blockers.slice(0,2).join('；'):technical?technicalReason+warning:watch?`短均線靠近、價格高低區間墊高；等突破${trigger}，量達${round(Math.max(3000,last.volume/1000*2),0)}張以上。`:episode?`${signalDate}已出現突破，今天不是新的突破訊號。${warning}`:'尚未同時符合短均線靠近、交錯與頭底墊高。';
 const nextStep=technical?`訊號日收盤${round(last.close)}為歷史參考；下一交易日須重核量價與防守距離，不能假設成交在此。`:watch?'觀察下個交易日的紅K、突破價格與成交量，成立後才評估。':'等待新的整理與量價確認，不沿用舊買價。';
 const commentary={decision,reason,nextStep,blockers,waitingPhase:stage};
 const plan={trigger,referenceClose:episode?b[episode.index].close:null,referenceDate:signalDate,referenceHigh,referenceLow:trigger,entryLow:null,entryHigh:null,candidateLow:technical?trigger:null,candidateHigh:technical?referenceHigh:null,stop,signalLow,signalDate,ma10,ma10Date:date,ma10Distance:distance(ma10),signalLowDistance:distance(signalLow),defenseDistance,exitRule:'MA10_OR_SIGNAL_LOW',target1:resistance?.value??null,target2:null,targetKind:resistance?'歷史壓力':'沒有可核對上方壓力',horizon:'依十日線與突破K低點追蹤',evidence:{support:{type:'突破K最低價',value:signalLow,date:signalDate},resistance,buffer:0,signalInvalidation:{moving:ma10,support:signalLow,note:'進場次日起，收盤先跌破十日線或原突破K低點就退出；不延後啟用，不另加緩衝。'}}};
 return {ready:true,ruleVersion:RULE_VERSION,code,name:c.quote?.name,market,sector,date,count:n,price:last.close,changePct:(last.close/prev.close-1)*100,ma5,ma10,ma20,ma60,bias5,aboveBreakout,priorSpreadPct:spread(n-2)*100,structure,risk,excluded,actionsClear,dataMismatch,abnormalGap,quality,stage,bucket,technical,actionable,priority,potential,entry,ranking,potentialParts,entryParts,plan,commentary,verdict:reason,strategy,strategyPhase:stage,strategyEvidence:episode?.evidence??classify(n-1).evidence,pattern:strategy,patternState:technical?'當日確認':episode?'過去已確認':'觀察中',patternEvidence:'頭底結構以前後各15日區間高低點上移近似；型態標籤待人工核對。',signalDate,signalAge,signalVolumeLots:signalBar.volume/1000,signalVolumeRatio:signalRatio,volumeLots:last.volume/1000,vsYesterday:f.ratio,vr:last.volume/mean(b.slice(-21,-1).map(x=>x.volume)),volumeText:`當日成交${round(f.lots,0)}張，前日${round(f.ratio)}倍；突破最低要求為前日2倍且3000張。`,requiredNextLots:Math.max(3000,last.volume/1000*2),caps:blockers,liquid:last.volume>=3000000,horizon:plan.horizon,alignment:{bull},extensionPct:(last.close/ma20-1)*100};
}
export function selectPriority(rows:any[],limit=3){return rows.filter(r=>r.ready&&r.priority).sort((a,z)=>z.entry-a.entry||z.potential-a.potential||a.code.localeCompare(z.code)).slice(0,limit)}
