export type Bar={date:string,open:number,high:number,low:number,close:number,volume:number};
export type Quote={code:string,name:string,market:string,close:number,change:number,volume:number,amount:number,date:string};
export function analyze(bars:Bar[]):any{
 const b=bars.filter(x=>x.close>0).sort((a,b)=>a.date.localeCompare(b.date)); const n=b.length;
 if(n<65)return {ready:false,count:n,reason:'至少需要65個交易日才能檢查季線與趨勢'};
 const avg=(a:number,z:number)=>b.slice(a,z).reduce((s,x)=>s+x.close,0)/(z-a);
 const ma5=avg(n-5,n),ma10=avg(n-10,n),ma20=avg(n-20,n),ma60=avg(n-60,n),old20=avg(n-25,n-5);
 const last=b[n-1],prev=b[n-2],prior=b.slice(n-21,n-1),top=Math.max(...prior.map(x=>x.high)),support=Math.min(...b.slice(n-11,n-1).map(x=>x.low));
 const volAvg=prior.reduce((s,x)=>s+x.volume,0)/20,vr=volAvg>0?last.volume/volAvg:0,extension=(last.close/ma20-1)*100;
 const trend=last.close>ma20&&ma20>ma60&&ma20>old20;
 const recent=b.slice(n-9,n-1),pullback=recent.some((x,i)=>i>0&&x.close<recent[i-1].close)&&Math.min(...recent.map(x=>x.low))<Math.max(...recent.map(x=>x.high))*.97;
 const trigger=Math.max(...b.slice(n-4,n-1).map(x=>x.high));
 const turn=last.close>trigger&&last.close>ma5&&last.close>prev.close;
 const downVol=b.slice(n-6,n-1).filter((x,i,a)=>i>0&&x.close<a[i-1].close);const contracted=downVol.length>0&&downVol.reduce((s,x)=>s+x.volume,0)/downVol.length<volAvg;
 const pull=trend&&pullback&&turn&&extension<=12;
 const breakout=trend&&last.close>top&&vr>=1.3&&extension<=15;
 const hot=vr>=1.5&&last.close>prev.close;
 const state=!trend?'趨勢待確認':extension>12?'乖離偏大':pull?'回檔轉強':breakout?'放量突破':pullback?'等待轉強':'多頭觀察';
 const stop=support;const risk=last.close-stop;const reward=top-last.close;
 return {ready:true,count:n,ma5,ma10,ma20,ma60,vr,extension,trend,pull,breakout,hot,state,support,trigger,top,stop,contracted,date:last.date,price:last.close,change:(last.close/prev.close-1)*100,rewardRisk:risk>0&&reward>0?reward/risk:null,score:(trend?35:0)+(pull?25:0)+(breakout?25:0)+(vr>=1.3?10:0)+(contracted?5:0),reason:[trend?'月線上彎且高於季線':'尚未符合多頭排列',pull?'回檔後突破近三日高點':breakout?'收盤突破前20日高點':pullback?'近期已有回檔，等待價格轉強':'目前尚未出現回檔轉強',`成交量為前20日均量的${vr.toFixed(2)}倍`,contracted?'回檔日量能較均量低':'回檔縮量尚未確認']};
}
export function validateBars(input:any):Bar[]{if(!Array.isArray(input)||input.length>1500)throw new Error('K線資料格式不正確');const dates=new Set();return input.map(x=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(x.date)||dates.has(x.date)||['open','high','low','close','volume'].some(k=>!Number.isFinite(x[k]))||x.close<=0||x.open<=0||x.low<=0||x.volume<0||x.high<Math.max(x.open,x.close,x.low)||x.low>Math.min(x.open,x.close))throw new Error('K線有重複日期或不合理數值');dates.add(x.date);return x;}).sort((a,b)=>a.date.localeCompare(b.date));}
