// Anchor each episode to its original signal; a later signal cannot repair a failed one.
export function followSignal(anchor:any,detail:any,expected:string,marketVerified:boolean){
 const a=detail?.analysis||{},bars=detail?.bars||[],original=bars.find((b:any)=>b.date===anchor.signalDate);const low=original?.low??anchor.signalLow;
 const after=bars.filter((b:any)=>b.date>anchor.signalDate);let failed:any=anchor.failure||null;
 for(const b of failed?[]:after){const i=bars.indexOf(b),window=bars.slice(i-9,i+1);const m10=window.length===10?window.reduce((s:number,v:any)=>s+v.close,0)/10:null;if(b.close<low||(m10!==null&&b.close<m10)){failed={date:b.date,price:b.close,reason:b.close<low?'原突破K低點':'當日十日線'};break;}}
 const base={...anchor,latest:a,signalLow:low,checkedDate:a.date,failed};
 if(!marketVerified||!expected||a.date!==expected||a.dataMismatch||!a.ready)return {...base,status:'資料待更新',decision:'暫無法判斷',reason:`資料至${a.date||'未取得'}；最新交易日${expected||'尚待核對'}，請更新後再判斷。`,canConsider:false};
 if(failed)return {...base,status:'訊號失效',decision:'取消這次買點',reason:`${failed.date}收盤${failed.price}已跌破${failed.reason}；即使後續反彈也不沿用原訊號。`,canConsider:false};
 if(!anchor.signalDate)return {...base,status:'等待突破',decision:'先鎖股，等待量價確認',reason:'尚無完整突破訊號；觀察短均線靠近、頭底墊高及帶量紅K突破。',canConsider:false};
 if(!original)return {...base,status:'資料待更新',decision:'原訊號待核對',reason:'日K未涵蓋原突破日，無法確認這次訊號是否曾失效。',canConsider:false};
 if(!a.actionable)return {...base,status:'核對／風險待處理',decision:'暫不進場',reason:(a.commentary?.blockers||[]).join('；')||a.risk?.reason,canConsider:false};
 const last=bars.at(-1),prev=bars.at(-2),near=a.bias5>=-1&&a.bias5<=3;const shrunk=prev&&last.volume<prev.volume;const red=last.close>last.open;const weak=last.close<last.open&&last.close/last.open-1<=-.03;
 if(a.date===anchor.signalDate)return {...base,status:'突破日，評估價格',decision:'買點成立，仍須評估風險',reason:'原突破條件成立；五日線乖離與防守距離仍需人工確認。',canConsider:false};
 if(near&&shrunk&&red&&last.close>=a.ma5)return {...base,status:'回測接近買點',decision:'可列入進場觀察',reason:'接近五日線、量縮收紅並收在五日線上；原突破結構仍有效，請再核對實際價格與防守距離。',canConsider:true};
 if(near)return {...base,status:'回測接近買點',decision:weak?'等待賣壓減輕':'等待止穩確認',reason:weak?'接近五日線但今天明顯收黑，不能只因價格接近就承接。':'已靠近五日線；尚未同時確認量縮、收紅及站回五日線。',canConsider:false};
 if(a.alignment?.bull&&a.price>=a.ma5)return {...base,status:'趨勢延續',decision:'結構有效，留意追高',reason:'五＞十＞二十日線，價格守在五日線上；趨勢延續不等於現在適合追價。',canConsider:false};
 return {...base,status:'等待回測',decision:'等待新的進場確認',reason:'原突破防守仍有效，觀察五日線附近的量縮與止穩，不沿用原突破收盤作今日買價。',canConsider:false};
}
