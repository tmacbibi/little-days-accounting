import type {Bar} from './analysis';
export const COSTS={buy:.0025,sell:.0055,label:'試算買入成本0.25%、賣出成本0.55%，含費用、稅與滑價；實際成本可能不同'};
export const tick=(v:number)=>v<10?.01:v<50?.05:v<100?.1:v<500?.5:v<1000?1:5;
// Provider OHLC often carries Float32 noise. Only source price levels may snap;
// calculated risk/cost bounds retain conservative directional rounding.
export function snapSourcePrice(v:number){const step=tick(v),nearest=Math.round(v/step)*step;const tolerance=Math.min(step*.001,Math.max(1e-8,Math.abs(v)*2e-7));return Math.abs(v-nearest)<=tolerance?Number(nearest.toFixed(2)):v;}
export const priceUp=(v:number,sourceNoise=false)=>{const value=sourceNoise?snapSourcePrice(v):v;return Number((Math.ceil((value-Number.EPSILON*Math.abs(value)*8)/tick(value))*tick(value)).toFixed(2));};
export const priceDown=(v:number,sourceNoise=false)=>{const value=sourceNoise?snapSourcePrice(v):v;return Number((Math.floor((value+Number.EPSILON*Math.abs(value)*8)/tick(value))*tick(value)).toFixed(2));};
const mean=(v:number[])=>v.reduce((s,x)=>s+x,0)/(v.length||1);
type Pivot={index:number,date:string,value:number};
export function structuralSupport(b:Bar[],ref:number,strategy?:string){const days=strategy==='糾結突破'?15:5;const window=b.slice(Math.max(0,ref-days),ref);const anchor=window.reduce((a,x)=>x.low<a.low?x:a,window[0]);return {type:strategy==='糾結突破'?'突破前15日整理區下緣':'轉強前5日低點',value:anchor.low,date:anchor.date,windowDays:days,state:'結構參考，並非保證守住'};}
export function resistanceZones(candidates:any[],b:Bar[],atr:number){
 const zones:any[]=[];
 for(const c of candidates.slice().sort((a,z)=>a.value-z.value)){const old=zones.at(-1);if(old&&c.value-old.value<=atr*.35){old.upper=Math.max(old.upper,c.value);old.sources.push({...c});if(!old.dates.includes(c.date))old.dates.push(c.date);}else zones.push({...c,upper:c.value,dates:[c.date],sources:[{...c}]});}
 for(const zone of zones){const confirmed=zone.sources.filter((s:any)=>s.confirmed&&Number.isInteger(s.index)).sort((a:any,z:any)=>a.index-z.index);const tests:any[]=[];for(const c of confirmed){const prior=tests.at(-1);const separated=!prior||(c.index-prior.index>=5&&b.slice(prior.index+1,c.index).some(x=>x.low<=Math.min(prior.value,c.value)-atr*.5));if(separated)tests.push(c);}zone.testDates=tests.map(c=>c.date);zone.testCount=tests.length;zone.strength=tests.length>=2?'多次高點重疊':tests.length===1?'單次高點':'整理區上緣待確認';zone.dates.sort();}
 return zones;
}
export function priceEvidence(b:Bar[],atr:number,trigger:number,episode:any,highs:Pivot[],lows:Pivot[],ma5:number,ma20:number){
 const n=b.length,date=b.at(-1)!.date,ref=episode?.index??n-1,planATR=episode?.atr||atr;
 const gaps:any[]=[];
 for(let i=Math.max(1,n-60);i<n;i++){
  const bottom=b[i-1].high,top=b[i].low;
  if(top-bottom>=Math.max(tick(bottom),atr*.15)&&Math.min(...b.slice(i).map(x=>x.low))>bottom){gaps.push({type:'向上跳空缺口',value:bottom,upper:top,date:b[i].date,state:Math.min(...b.slice(i+1).map(x=>x.low))<top?'部分回補':'尚未回補',index:i});}
 }
 let support:any=structuralSupport(b,ref,episode?.strategy);
 const low=lows.find(x=>x.date===support.date&&x.index+2<=ref);
 if(low)support={...support,type:'已確認回檔低點',confirmed:b[low.index+2].date};
 const formationGap=gaps.find(g=>g.index===ref&&g.value>=trigger-tick(trigger)&&b[ref].volume>=mean(b.slice(Math.max(0,ref-20),ref).map(x=>x.volume))*1.2);
 if(episode&&formationGap)support={...formationGap,type:'突破當日向上缺口下緣',state:'回補缺口表示突破結構減弱'};
 // Freeze the initial structural plan at the signal date. Later gap fills or
 // volatility changes cannot silently widen or replace that support/stop.
 if(episode?.initialEvidence)support={...episode.initialEvidence.support};
 const stop=episode?.initialEvidence?.stop??priceDown(Math.max(.01,support.value-planATR*.35));
 const candidates:any[]=highs.filter(x=>x.index<n-1&&x.value>Math.max(trigger,b.at(-1)!.close)+tick(trigger)).map(x=>({...x,type:'已確認歷史高點',confirmed:b[x.index+2].date}));
 const box=b.slice(-21,-1),boxTop=Math.max(...box.map(x=>x.high)),boxLow=Math.min(...box.map(x=>x.low));
 const boxPeak=box.find(x=>x.high===boxTop)!;
 if(boxTop>Math.max(trigger,b.at(-1)!.close)&&!candidates.some(x=>x.date===boxPeak.date&&x.value===boxTop))candidates.push({index:b.indexOf(boxPeak),value:boxTop,date:boxPeak.date,type:'前20日整理區上緣',confirmed:null});
 const zones=resistanceZones(candidates,b,atr);
 const width=boxTop-boxLow;
 const target1=zones[0]?priceDown(zones[0].value,true):priceDown(Math.max(trigger+atr*2,boxTop+Math.min(width*.5,atr*3)));
 const target2=zones[1]?priceDown(zones[1].value,true):priceDown(Math.max(target1+atr,boxTop+Math.min(width,atr*5)));
 const describe=(zone:any,value:number,note:string)=>({...zone,rawValue:zone.value,rawUpper:zone.upper,value,upper:snapSourcePrice(zone.upper),note});
 const resistance=zones[0]?describe(zones[0],target1,'最近第一壓力仍保留；強度不代表必達，也不跳過較近壓力'):{type:'整理幅度與日波動量度',value:target1,date,note:'缺少上方歷史壓力，採條件式推估，評分折減'};
 const target2Basis=zones[1]?describe(zones[1],target2,'第一壓力有效突破後才重新評估'):{type:'整理幅度與日波動量度',value:target2,date,note:'條件式推估，須第一壓力突破後重估'};
 const signalInvalidation=episode?{date:b[ref].date,support: support.value,moving:ma5,note:'買入訊號：收盤跌破當日五日線或原始結構支撐即失效；初始停損另保留0.35倍訊號當日日波動空間，兩者不同。'}:null;
 return {support,stop,buffer:planATR*.35,planATR,target1,target2,targetKind:zones[0]?'歷史壓力':'型態量度推估',resistance,target2Basis,signalInvalidation,gaps:gaps.slice(-3),moving:[{type:'五日均線',value:ma5,date,note:'買入訊號失效與动态觀察參考，不是本次初始停損'},{type:'二十日均線',value:ma20,date,note:'趨勢參考，須配合回檔結構判讀'}]};
}
export function feasibleEntry(trigger:number,chaseHigh:number,stop:number,target:number){
 // Net reward at target / net loss at stop >= 1.5, using one cost basis.
 const rrHigh=(target*(1-COSTS.sell)+1.5*stop*(1-COSTS.sell))/(2.5*(1+COSTS.buy));
 const low=priceUp(trigger),high=priceDown(Math.min(chaseHigh,rrHigh));
 return {low,high:high>=low&&stop<low?high:null,rrHigh:priceDown(rrHigh),chaseHigh:priceDown(chaseHigh)};
}
export function netRewardRisk(entry:number,stop:number,target:number){const paid=entry*(1+COSTS.buy),loss=paid-stop*(1-COSTS.sell);return loss>0?(target*(1-COSTS.sell)-paid)/loss:0;}
