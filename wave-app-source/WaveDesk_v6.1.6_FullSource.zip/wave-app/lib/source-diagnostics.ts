import {db,read,save} from './storage';
// 官方行情／公告來源的診斷紀錄。只觀測，不改變任何抓取或轉址行為。
// 安全界線：
//  - 只記錄回應標頭白名單（content-type、server、cf-ray、cf-mitigated、retry-after、content-length）與 Location 的「網址+路徑」。
//  - 不記錄 Cookie / Set-Cookie / Authorization，也不記錄請求標頭；不保存來源回應內文，只保存「內文種類」與最多 80 字的 <title>（僅供伺服器端診斷）。
//  - 畫面只使用 SourceSummary（來源名稱、狀態碼、簡短原因、時間）。

export type SourceKind='ok'|'empty'|'redirect'|'http'|'timeout'|'network'|'parse';
export type SourceDetail={location?:string;contentType?:string;server?:string;cfRay?:string;cfMitigated?:string;retryAfter?:string;contentLength?:string;bodyKind?:'json'|'html'|'text'|'empty';htmlTitle?:string;jsonShape?:string;error?:string};
export type SourceRecord={label:string;target:string;name:string;at:string;ms:number;kind:SourceKind;status:number|null;reason:string;detail:SourceDetail};
export type SourceSummary={label:string;name:string;at:string;kind:SourceKind;status:number|null;reason:string};

// 固定的官方來源登錄：只有這些會寫入 D1（每個來源只保留最近一次嘗試）。
const REGISTRY:Record<string,{label:string;name:string}>={
 'www.tpex.org.tw/web/stock/aftertrading/DAILY_CLOSE_quotes/stk_quote_result.php':{label:'tpex_quotes_csv',name:'上櫃官方下載'},
 'openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL':{label:'twse_stock_day_all',name:'上市行情'},
 'www.twse.com.tw/exchangeReport/MI_INDEX':{label:'twse_mi_index',name:'上市收盤表'},
 'openapi.twse.com.tw/v1/indicesReport/MI_5MINS_HIST':{label:'twse_mi_5mins_hist',name:'上市指數'},
 'www.twse.com.tw/rwd/zh/announcement/notice':{label:'twse_notice',name:'上市注意公告'},
 'www.twse.com.tw/rwd/zh/announcement/notetrans':{label:'twse_notetrans',name:'上市預警公告'},
 'www.twse.com.tw/rwd/zh/announcement/punish':{label:'twse_punish',name:'上市處置公告'},
 'www.twse.com.tw/exchangeReport/TWT49U':{label:'twse_twt49u',name:'上市權息'},
 'www.tpex.org.tw/openapi/v1/tpex_mainboard_quotes':{label:'tpex_mainboard_quotes',name:'上櫃行情'},
 'www.tpex.org.tw/openapi/v1/tpex_mainboard_daily_close_quotes':{label:'tpex_mainboard_daily_close_quotes',name:'上櫃行情（備援）'},
 'www.tpex.org.tw/openapi/v1/tpex_trading_warning_information':{label:'tpex_trading_warning_information',name:'上櫃注意公告'},
 'www.tpex.org.tw/openapi/v1/tpex_trading_warning_note':{label:'tpex_trading_warning_note',name:'上櫃預警公告'},
 'www.tpex.org.tw/openapi/v1/tpex_disposal_information':{label:'tpex_disposal_information',name:'上櫃處置公告'},
 'www.tpex.org.tw/www/zh-tw/bulletin/exDailyQ':{label:'tpex_ex_daily_q',name:'上櫃權息'},
};
const clean=(s:unknown,max:number)=>String(s??'').replace(/[\u0000-\u001f\u007f]/g,' ').slice(0,max);
function hostPath(url:string){try{const u=new URL(url);return u.host+u.pathname}catch{return clean(url,80)}}
const isTpex=(url:string)=>{try{return new URL(url).host.endsWith('tpex.org.tw')}catch{return false}};
// Location 只留「網址+路徑」，丟掉查詢字串與片段（可能夾帶識別碼）。
export function safeLocation(loc:string|null,base:string){if(!loc)return '(無 Location)';try{const u=new URL(loc,base);return clean(u.origin+u.pathname,200)}catch{return '(Location 無法解析)'}}
function pickHeaders(r:Response):SourceDetail{const g=(k:string)=>{const v=r.headers.get(k);return v?clean(v,120):undefined};return {contentType:g('content-type'),server:g('server'),cfRay:g('cf-ray'),cfMitigated:g('cf-mitigated'),retryAfter:g('retry-after'),contentLength:g('content-length')};}
// Diagnostics are best effort: neither stalled bodies nor D1 may block research.
export async function bounded<T>(work:Promise<T>,ms:number,fallback:T):Promise<T>{let timer:ReturnType<typeof setTimeout>|undefined;try{return await Promise.race([work.catch(()=>fallback),new Promise<T>(resolve=>{timer=setTimeout(()=>resolve(fallback),ms)})]);}finally{clearTimeout(timer);}}
async function peek(r:Response,max=2048){let reader:ReadableStreamDefaultReader<Uint8Array>|undefined;let active=true;try{return await bounded((async()=>{const body=r.clone().body;if(!body)return '';reader=body.getReader();const parts:Uint8Array[]=[];let got=0;while(active&&got<max){const {done,value}=await reader.read();if(done||!active)break;const part=value.subarray(0,max-got);parts.push(part);got+=part.length;}const all=new Uint8Array(got);let at=0;for(const p of parts){all.set(p,at);at+=p.length;}return new TextDecoder().decode(all);})(),200,'');}finally{active=false;void reader?.cancel().catch(()=>{});}}

export function bodyInfo(text:string,contentType?:string):Pick<SourceDetail,'bodyKind'|'htmlTitle'>{const t=text.trimStart();if(!t)return {bodyKind:'empty'};if(t.startsWith('<')||/html/i.test(contentType||'')){const m=t.match(/<title[^>]*>([\s\S]{0,300}?)<\/title>/i);const title=m?clean(m[1].replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim(),80):'';return title?{bodyKind:'html',htmlTitle:title}:{bodyKind:'html'};}if(t.startsWith('{')||t.startsWith('['))return {bodyKind:'json'};return {bodyKind:'text'};}
export function reasonFor(kind:SourceKind,status:number|null,detail:SourceDetail){switch(kind){case 'ok':return '正常';case 'empty':return '回應為空陣列';case 'redirect':return `收到轉址（${status}），目的地已記錄於伺服器，原因尚未判定`;case 'http':return `來源回應 HTTP ${status}`;case 'timeout':return '連線逾時';case 'network':return '連線失敗';case 'parse':return `回應不是預期的 JSON（${detail.bodyKind||'未知'}）`;}}
const taipeiStamp=(v:string|number)=>new Intl.DateTimeFormat('zh-TW',{timeZone:'Asia/Taipei',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(v));

async function record(url:string,x:{kind:SourceKind;status:number|null;ms:number;detail:SourceDetail}){
 try{const target=hostPath(url);const meta=REGISTRY[target];if(!meta&&(x.kind==='ok'||x.kind==='empty'))return;
  const rec:SourceRecord={label:meta?.label||target.slice(0,80),target,name:meta?.name||'其他來源',at:new Date().toISOString(),ms:x.ms,kind:x.kind,status:x.status,reason:reasonFor(x.kind,x.status,x.detail),detail:x.detail};
  if(x.kind!=='ok'&&(meta||isTpex(url)))console.error('source-diag',JSON.stringify(rec));
  if(meta)await bounded(save('source-diag:'+meta.label,rec),200,undefined);
 }catch{/* 診斷不得影響更新流程 */}
}
// 以下 note* 皆「永不丟錯」，且不消耗呼叫端要讀的原始回應內文（以 clone 取樣）。
export async function noteSourceError(url:string,e:unknown,t0:number){const name=(e as any)?.name;const timeout=name==='TimeoutError'||name==='AbortError';await record(url,{kind:timeout?'timeout':'network',status:null,ms:Date.now()-t0,detail:{error:clean(`${name||'Error'}: ${(e as any)?.message||''}`,160)}});}
export async function noteSourceHttp(url:string,r:Response,t0:number){try{const detail=pickHeaders(r);const redirect=r.status>=300&&r.status<400;if(redirect)detail.location=safeLocation(r.headers.get('location'),url);Object.assign(detail,bodyInfo(await peek(r),detail.contentType));await record(url,{kind:redirect?'redirect':'http',status:r.status,ms:Date.now()-t0,detail});}catch{}}
export async function noteSourceParse(url:string,r:Response,t0:number,text:string){try{const detail=pickHeaders(r);Object.assign(detail,bodyInfo(text.slice(0,2048),detail.contentType));await record(url,{kind:'parse',status:r.status,ms:Date.now()-t0,detail});}catch{}}
export async function noteSourceOk(url:string,r:Response,t0:number,value:unknown){try{const shape=Array.isArray(value)?`array(${value.length})`:value&&typeof value==='object'?`object(${Object.keys(value as object).length} keys)`:typeof value;await record(url,{kind:Array.isArray(value)&&value.length===0?'empty':'ok',status:r.status,ms:Date.now()-t0,detail:{...pickHeaders(r),jsonShape:shape}});}catch{}}

// ---- 畫面用摘要：只含來源名稱、狀態碼、簡短原因、時間 ----
export async function readSourceSummaries():Promise<SourceSummary[]>{try{const rows=await db().prepare("SELECT value FROM store WHERE key LIKE 'source-diag:%'").all<{value:string}>();return rows.results.map(r=>JSON.parse(r.value) as SourceRecord).map(({label,name,at,kind,status,reason})=>({label,name,at,kind,status,reason}));}catch{return [];}}
export function summaryLines(list:SourceSummary[]):string[]{return list.filter(s=>s.kind!=='ok').sort((a,b)=>a.label.localeCompare(b.label)).map(s=>`${s.name}：${s.reason}${s.status?`（HTTP ${s.status}）`:''}，最近一次嘗試 ${taipeiStamp(s.at)}`);}
// 「已嘗試」與「核對成功」分開：2 分鐘內不重連只代表近期已嘗試。
export function attemptNotice(at:number|null,reused:boolean,someUnverified:boolean){return reused&&someUnverified&&at?`行情來源近期已嘗試（${taipeiStamp(at)}），2 分鐘內不重複連線；這不代表核對成功，未核對的市場仍保留原行情`:'';}
export async function readSourceDetails(){try{const rows=await db().prepare("SELECT value FROM store WHERE key LIKE 'source-diag:%'").all<{value:string}>();const last=await read('source-probe-last');return {records:rows.results.map(r=>JSON.parse(r.value) as SourceRecord),lastProbe:last?.data||null};}catch{return {records:[],lastProbe:null};}}

// ---- 探測：只能測下列固定官方網址，不接受任何外部輸入的網址 ----
export type ProbeTarget={label:string;name:string;url:string};
export type ProbeResult={label:string;name:string;variant:'current'|'plain';kind:SourceKind;status:number|null;ms:number;detail:SourceDetail};
const taipeiDay=(ms:number)=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Taipei',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(ms));
export function probeTargets(now=Date.now()):ProbeTarget[]{const end=taipeiDay(now);const start=taipeiDay(now-7*86400000);const q=(s:string)=>s.replaceAll('-','/');const o='https://www.tpex.org.tw/openapi/v1/';return [
 {label:'tpex_quotes_csv',name:'上櫃官方行情CSV',url:'https://www.tpex.org.tw/web/stock/aftertrading/DAILY_CLOSE_quotes/stk_quote_result.php?l=zh-tw&o=data'},
 {label:'tpex_attention_csv',name:'上櫃注意CSV',url:'https://www.tpex.org.tw/www/zh-tw/bulletin/attention?response=data'},
 {label:'tpex_disposal_csv',name:'上櫃處置CSV',url:'https://www.tpex.org.tw/web/bulletin/disposal_information/disposal_information_result.php?l=zh-tw&o=data'},
 {label:'tpex_actions_csv',name:'上櫃權息CSV',url:'https://www.tpex.org.tw/web/stock/exright/dailyquo/exDailyQ_result.php?l=zh-tw&o=data'},
 {label:'twse_stock_day_all',name:'上市行情（對照組）',url:'https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL'},
 {label:'tpex_mainboard_quotes',name:'上櫃行情',url:o+'tpex_mainboard_quotes'},
 {label:'tpex_mainboard_daily_close_quotes',name:'上櫃行情（備援）',url:o+'tpex_mainboard_daily_close_quotes'},
 {label:'tpex_trading_warning_information',name:'上櫃注意公告',url:o+'tpex_trading_warning_information'},
 {label:'tpex_trading_warning_note',name:'上櫃預警公告',url:o+'tpex_trading_warning_note'},
 {label:'tpex_disposal_information',name:'上櫃處置公告',url:o+'tpex_disposal_information'},
 {label:'tpex_ex_daily_q',name:'上櫃權息',url:`https://www.tpex.org.tw/www/zh-tw/bulletin/exDailyQ?startDate=${q(start)}&endDate=${q(end)}&response=json`},
];}
// current：與 lib/market.ts json() 目前送出的標頭相同（改動 market.ts 標頭時須同步）。
// plain：如實自報身分、不帶 Referer/Accept-Language，僅供「對照觀測」，不是正式環境的修正。
export function requestHeaders(url:string,variant:'current'|'plain'):Record<string,string>{if(variant==='plain')return {Accept:'application/json','User-Agent':'wave-desk-diagnostic/6.1.2 (personal research tool)'};return {'Accept':'application/json','Accept-Language':'zh-TW,zh;q=0.9','User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36','Referer':url.includes('tpex.org')?'https://www.tpex.org.tw/':url.includes('twse.com.tw')?'https://www.twse.com.tw/':'https://finance.yahoo.com/'};}
async function probeOne(t:ProbeTarget,variant:'current'|'plain'):Promise<ProbeResult>{const t0=Date.now();const base={label:t.label,name:t.name,variant};
 try{const r=await fetch(t.url,{cache:'no-store',redirect:'manual',signal:AbortSignal.timeout(8000),headers:requestHeaders(t.url,variant)});const detail=pickHeaders(r);const redirect=r.status>=300&&r.status<400;if(redirect)detail.location=safeLocation(r.headers.get('location'),t.url);Object.assign(detail,bodyInfo(await peek(r),detail.contentType));void r.body?.cancel().catch(()=>{});
  const kind:SourceKind=redirect?'redirect':!r.ok?'http':detail.bodyKind==='json'?'ok':'parse';return {...base,kind,status:r.status,ms:Date.now()-t0,detail};}
 catch(e){const name=(e as any)?.name;return {...base,kind:name==='TimeoutError'||name==='AbortError'?'timeout':'network',status:null,ms:Date.now()-t0,detail:{error:clean(`${name||'Error'}: ${(e as any)?.message||''}`,160)}};}}
export async function probeOfficialSources(now=Date.now()){const jobs=probeTargets(now).flatMap(t=>{const variants:('current'|'plain')[]=(t.label==='twse_stock_day_all'||t.label.endsWith('_csv'))?['current']:['current','plain'];return variants.map(v=>()=>probeOne(t,v));});const results:ProbeResult[]=[];for(let i=0;i<jobs.length;i+=4)results.push(...await Promise.all(jobs.slice(i,i+4).map(j=>j())));const out={at:new Date(now).toISOString(),note:'僅為觀測結果，不構成原因判定；plain 為對照組，不代表正式環境應採用',results};await bounded(save('source-probe-last',out),500,undefined);return out;}

// ---- 探測的存取頻率限制（D1 原子 upsert）：全站每 60 秒最多 1 次、每個臺灣日最多 12 次 ----
export const PROBE_MIN_GAP_MS=60_000,PROBE_DAILY_MAX=12;
export async function claimProbeSlot(now=Date.now()):Promise<{ok:true}|{ok:false;reason:'gap'|'daily';retryAfter:number}>{
 const gate=await db().prepare("INSERT INTO store (key,value,updated) VALUES ('probe-gate','{}',?) ON CONFLICT(key) DO UPDATE SET updated=excluded.updated WHERE store.updated<=? RETURNING updated").bind(now,now-PROBE_MIN_GAP_MS).first<{updated:number}>();
 if(!gate){const row=await db().prepare("SELECT updated FROM store WHERE key='probe-gate'").first<{updated:number}>();return {ok:false,reason:'gap',retryAfter:Math.max(1,Math.ceil(((row?.updated||now)+PROBE_MIN_GAP_MS-now)/1000))};}
 const day=await db().prepare("INSERT INTO store (key,value,updated) VALUES (?,'1',?) ON CONFLICT(key) DO UPDATE SET value=CAST(CAST(store.value AS INTEGER)+1 AS TEXT),updated=excluded.updated WHERE CAST(store.value AS INTEGER)<? RETURNING value").bind('probe-count:'+taipeiDay(now),now,PROBE_DAILY_MAX).first<{value:string}>();
 if(!day)return {ok:false,reason:'daily',retryAfter:3600};
 return {ok:true};
}
