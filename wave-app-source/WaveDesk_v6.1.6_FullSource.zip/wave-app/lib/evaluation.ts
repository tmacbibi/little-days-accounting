import {COSTS} from './pricing';
import type {Bar} from './analysis';
export const SIMULATION={buyCost:COSTS.buy,sellCost:COSTS.sell,label:'試算假設：買入成本0.25%、賣出成本0.55%，合計含手續費、稅與滑價；不是你的實際費率'};
// An archived decision is never recalculated from future prices.
export function evaluateSignal(row:any,date:string,bars:Bar[],events:any[]=[],calendar:string[]=[],levelFactor?:number){
 const future=bars.filter(x=>x.date>date).sort((a,b)=>a.date.localeCompare(b.date));
 if(!future.length)return {status:'等待後續交易日',outcomes:[]};
 const relevant=events.filter(e=>e.date>date&&e.date<=future.at(-1)!.date);
 if(relevant.some(e=>e.kind?.includes('權')))return {status:'除權事件待核對',outcomes:[]};
 const factor=levelFactor??relevant.reduce((s,e)=>s*e.factor,1),plan=row.plan;
 const rawLow=plan.candidateLow??plan.entryLow,rawHigh=plan.candidateHigh??plan.entryHigh;if(rawLow==null||rawHigh==null)return {status:'沒有有效候選價區',outcomes:[]};
 const low=rawLow*factor,high=rawHigh*factor,stop=plan.stop*factor,target=plan.target1*factor;
 const required=calendar.filter(d=>d>date);
 if(required.length&&future[0].date!==required[0])return {status:'後續日K缺漏',outcomes:[]};
 const entry=future[0].open;
 if(entry<low||entry>high)return {status:'次日開盤不在進場區，未模擬買入',outcomes:[]};
 if(stop>=entry||(plan.exitRule!=='MA10_OR_SIGNAL_LOW'&&target<=entry))return {status:'原始價格計畫不適用',outcomes:[]};
 const outcomes=[];
 for(const horizon of [5,10,20]){
  if(future.length<horizon||required.length>0&&required.length<horizon||required.length&&required.slice(0,horizon).some((d,i)=>future[i]?.date!==d))continue;
  const window=future.slice(0,horizon);let exit=window.at(-1)!.close,reason='期末收盤',exitDate=window.at(-1)!.date;
  for(const b of window){
   if(plan.exitRule==='MA10_OR_SIGNAL_LOW'){
    const prefix=bars.filter(v=>v.date<=b.date);if(prefix.length<10)break;
    const ma10=prefix.slice(-10).reduce((s,v)=>s+v.close,0)/10;
    const signalLow=plan.signalLow*factor;
    if(b.close<ma10||b.close<signalLow){exit=b.close;reason='收盤失守十日線或突破K低點';exitDate=b.date;break;}
    continue;
   }
   // With daily bars the intraday order is unknown; a tie uses the stop first.
   if(b.open<=stop){exit=b.open;reason='跳空停損';exitDate=b.date;break;}
   if(b.open>=target){exit=b.open;reason='開盤達第一目標';exitDate=b.date;break;}
   if(b.low<=stop){exit=stop;reason=b.high>=target?'同日觸價，保守計停損':'停損';exitDate=b.date;break;}
   if(b.high>=target){exit=target;reason='第一目標';exitDate=b.date;break;}
  }
  const net=(exit*(1-SIMULATION.sellCost)/(entry*(1+SIMULATION.buyCost))-1)*100;
  outcomes.push({horizon,net,reason,exitDate});
 }
 return {status:outcomes.length?'已有成熟觀察期':'觀察期未滿5日',outcomes};
}
export function aggregateEvaluation(samples:any[]){
 const groups:any[]=[];
 for(const dimension of ['entry','potential'])for(const strategy of ['糾結後初次突破','上升途中整理再突破'])for(const horizon of [5,10,20])for(const [label,min,max] of [['低於65',0,65],['65～74',65,75],['75～84',75,85],['85以上',85,101]] as const){
  const outcomes=samples.filter(s=>s.strategy===strategy&&s[dimension]>=min&&s[dimension]<max).flatMap(s=>s.outcomes.filter((o:any)=>o.horizon===horizon));
  const n=outcomes.length;groups.push({dimension,strategy,horizon,band:label,n,average:n?outcomes.reduce((a:number,o:any)=>a+o.net,0)/n:null,worst:n?Math.min(...outcomes.map((o:any)=>o.net)):null,positiveRate:n?outcomes.filter((o:any)=>o.net>0).length/n*100:null,targetRate:n?outcomes.filter((o:any)=>o.reason.includes('目標')).length/n*100:null,stopRate:n?outcomes.filter((o:any)=>(o.reason.includes('停損')||o.reason.includes('失守'))).length/n*100:null});
 }
 return groups;
}
