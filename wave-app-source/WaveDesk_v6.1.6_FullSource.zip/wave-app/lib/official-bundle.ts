import officialReserve from './official-reserve.json';
import {read,save} from './storage';
export const BUNDLE_URL='https://raw.githubusercontent.com/tmacbibi/little-days-accounting/main/wave-data/latest.json';
export function validBundle(d:any){
 const day=d?.asOf;if(!/^\d{4}-\d{2}-\d{2}$/.test(day||''))return false;
 if(!Array.isArray(d.quotes)||d.quotes.length<700||!d.quotes.every((q:any)=>q.market==='TWO'&&q.date===day&&/^\d{4}$/.test(q.code)&&Number.isFinite(q.close)&&q.close>0&&Number.isFinite(q.volume)&&q.volume>=0&&[q.open,q.high,q.low].every(Number.isFinite)&&q.low>0&&q.high>=Math.max(q.open,q.close)&&q.low<=Math.min(q.open,q.close)))return false;
 if(!d.risk?.verified||d.risk.asOf!==day||!['attention','warning','disposal'].every(k=>Array.isArray(d.risk[k]))||!d.risk.attention.every((c:any)=>typeof c==='string')||!d.risk.warning.every((c:any)=>typeof c==='string')||!d.risk.disposal.every((r:any)=>typeof r.code==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(r.start)&&r.end>=r.start))return false;
 if(!d.actions?.verified||d.actions.asOf!==day||!/^\d{4}-\d{2}-\d{2}$/.test(d.actions.fromDate||'')||d.actions.fromDate>day||!Array.isArray(d.actions.events)||!d.actions.events.every((e:any)=>typeof e.code==='string'&&e.date>=d.actions.fromDate&&e.date<=day&&Number.isFinite(e.factor)&&e.factor>0))return false;
 if(!d.provenance?.retrievedAt||!d.provenance?.urls||!['quotes','attention','warning','disposal','actions'].every(k=>{try{return new URL(d.provenance.urls[k]).hostname==='www.tpex.org.tw'&&new URL(d.provenance.urls[k]).protocol==='https:'}catch{return false}}))return false;
 return true;
}
export async function officialBundle(){
 const cached=await read('official-daily-bundle');
 if(cached&&Date.now()-cached.updated<120000&&validBundle(cached.data))return cached.data;
 try{const r=await fetch(BUNDLE_URL,{cache:'no-store',signal:AbortSignal.timeout(8000),headers:{Accept:'application/json'}});if(!r.ok)throw Error();const data:any=await r.json();if(!validBundle(data)||data.asOf<(cached?.data?.asOf||officialReserve.asOf))throw Error();await save('official-daily-bundle',data);return data;}catch{if(cached&&validBundle(cached.data))return cached.data;return officialReserve;}
}
export function shortOfficialHistory(bundle:any,code:string,quote:any){
 const bars=bundle?.history?.[code];if(!validBundle(bundle)||!quote||quote.market!=='TWO'||quote.date!==bundle.asOf||!Array.isArray(bars)||!bars.length)return null;
 if(!bars.every((b:any,i:number)=>/^\d{4}-\d{2}-\d{2}$/.test(b.date)&&b.date<=bundle.asOf&&(!i||b.date>bars[i-1].date)&&[b.open,b.high,b.low,b.close,b.volume].every(Number.isFinite)&&b.low>0&&b.volume>=0&&b.high>=Math.max(b.open,b.close)&&b.low<=Math.min(b.open,b.close)))return null;
 if(bars.at(-1).date!==quote.date||Math.abs(bars.at(-1).close-quote.close)>0.01)return null;
 return {code,market:'TWO',bars,adjusted:false,source:'櫃買中心各日成交資訊（官方資料轉存，原始日K）',fetched:bundle.provenance.retrievedAt};
}
