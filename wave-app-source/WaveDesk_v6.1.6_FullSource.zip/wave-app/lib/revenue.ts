import initial from './initial-revenue.json';
import {db,read,save} from './storage';import {getJSON,normalDate} from './feeds';
import {revenueSummary,type RevenueRow} from './revenue-analysis';
const urls:Record<string,string>={TW:'https://openapi.twse.com.tw/v1/opendata/t187ap05_L',TWO:'https://www.tpex.org.tw/openapi/v1/mopsfin_t187ap05_O'};
const numeric=(v:any)=>{if(v==null||String(v).trim()==='')return null;const n=Number(String(v).replaceAll(',',''));return Number.isFinite(n)?n:null;};
const taipeiDate=()=>new Date(Date.now()+8*3600000).toISOString().slice(0,10);
export async function getRevenue(code:string,market:string){
 const seed=(initial.markets as any)[market];const records=await db().prepare("SELECT value FROM store WHERE key LIKE ? ORDER BY key DESC LIMIT 12").bind(`revenue:${market}:%`).all<{value:string}>();
 let fetched=seed?.fetched||initial.fetched;const rows:RevenueRow[]=(seed?.rows||[]).filter((r:any)=>r.code===code);
 for(const record of records.results.slice().reverse()){const batch=JSON.parse(record.value);rows.push(...batch.rows.filter((r:any)=>r.code===code));if(batch.fetched>fetched)fetched=batch.fetched;}
 return revenueSummary(rows,taipeiDate(),fetched);
}
export async function refreshRevenue(){
 const status=await read('revenue-refresh');if(status&&Date.now()-status.updated<6*3600000)return {messages:[],cached:true};
 const stamp=new Date().toISOString(),today=taipeiDate();let successes=0;const messages:string[]=[];
 await Promise.all(['TW','TWO'].map(async market=>{try{
  const raw=await getJSON(urls[market]);if(!Array.isArray(raw)||raw.length<100)throw Error('資料不完整');const groups=new Map<string,RevenueRow[]>();
  for(const r of raw){const ym=String(r['資料年月']),code=String(r['公司代號']);if(!/^\d{5}$/.test(ym)||!/^[1-9]\d{3}$/.test(code))continue;
   const month=`${Number(ym.slice(0,3))+1911}-${ym.slice(3)}`,value=numeric(r['營業收入-當月營收']);if(value===null||value<0||month>=today.slice(0,7))continue;
   const out:RevenueRow={code,name:r['公司名稱'],month,value,lastYear:numeric(r['營業收入-去年當月營收']),yoy:numeric(r['營業收入-去年同月增減(%)']),mom:numeric(r['營業收入-上月比較增減(%)']),note:r['備註']==='-'?'':r['備註'],source:urls[market]};const list=groups.get(month)||[];list.push(out);groups.set(month,list);
  }
  if(!groups.size)throw Error('缺少有效資料');for(const [month,rows] of groups)await save(`revenue:${market}:${month}`,{rows,fetched:stamp,sourceDate:normalDate(raw[0]['出表日期'])});successes++;
 }catch{messages.push(`${market==='TW'?'上市':'上櫃'}營收取得失敗，保留上次資料`)}}));
 if(successes===2)await save('revenue-refresh',{fetched:stamp});return {messages,cached:false};
}
