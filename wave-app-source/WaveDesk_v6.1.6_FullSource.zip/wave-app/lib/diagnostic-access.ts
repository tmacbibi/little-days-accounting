type Config={DIAGNOSTICS_OWNER_EMAIL?:string;DIAGNOSTICS_ADMIN_TOKEN?:string;DIAGNOSTICS_ADMIN_EXPIRES?:string};
// User identity must come from Sites-verified headers via getChatGPTUser, never request JSON.
export async function diagnosticAllowed(req:Request,config:Config,user:{userId:string;email:string}|null){
 if(user?.userId&&config.DIAGNOSTICS_OWNER_EMAIL&&user.email.toLowerCase()===config.DIAGNOSTICS_OWNER_EMAIL.toLowerCase())return true;
 const token=req.headers.get('x-wave-diagnostic-token');
 if(!token||!config.DIAGNOSTICS_ADMIN_TOKEN||Date.now()>=Date.parse(config.DIAGNOSTICS_ADMIN_EXPIRES||'')||!Number.isFinite(Date.parse(config.DIAGNOSTICS_ADMIN_EXPIRES||'')))return false;
 const digest=async(s:string)=>new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));
 const [a,b]=await Promise.all([digest(token),digest(config.DIAGNOSTICS_ADMIN_TOKEN)]);let diff=0;for(let i=0;i<a.length;i++)diff|=a[i]^b[i];return diff===0;
}
export function sameOrigin(req:Request){return req.headers.get('origin')===new URL(req.url).origin;}
