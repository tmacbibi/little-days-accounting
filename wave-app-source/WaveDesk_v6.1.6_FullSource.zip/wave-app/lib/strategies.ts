import type {Bar} from './analysis';
const avg=(v:number[])=>v.length?v.reduce((a,b)=>a+b,0)/v.length:0;
const sma=(b:Bar[],p:number,end=b.length)=>avg(b.slice(end-p,end).map(x=>x.close));
function volatility(b:Bar[]){return avg(b.slice(-14).map((x,i,a)=>Math.max(x.high-x.low,i?Math.abs(x.high-a[i-1].close):0,i?Math.abs(x.low-a[i-1].close):0)))||b.at(-1)!.close*.01;}
// Only bars available before a breakout are used to identify its base.
export function squeezeSetup(b:Bar[]){
 if(b.length<64)return null;
 const atr=volatility(b),end=b.length;let run=0,best=0,lastEnd=0;
 for(let e=Math.max(60,end-14);e<=end;e++){
  const lines=[5,10,20,60].map(p=>sma(b,p,e)),spread=Math.max(...lines)-Math.min(...lines);
  if(spread<=atr&&spread/sma(b,20,e)<=.03){run++;if(run>=5){best=run;lastEnd=e;}}else run=0;
 }
 if(best<5||end-lastEnd>5)return null;
 const range=b.slice(-15),top=Math.max(...range.map(x=>x.high)),low=Math.min(...range.map(x=>x.low));
 const short=b.slice(-5),older=b.slice(-15,-5);
 const contraction=(Math.max(...short.map(x=>x.high))-Math.min(...short.map(x=>x.low)))/(top-low||atr);
 const volumeRatio=avg(short.map(x=>x.volume))/(avg(older.map(x=>x.volume))||1);
 const m20=sma(b,20),m60=sma(b,60),slope20=(m20/sma(b,20,end-5)-1)*100,slope60=(m60/sma(b,60,end-5)-1)*100;
 const longImproving=slope20>=-.2&&slope60>=-.15;
 if(contraction>.8||volumeRatio>1.05||!longImproving)return null;
 return {top,low,days:best,atr,contraction,volumeRatio,slope20,slope60};
}
export function alignment(b:Bar[]){
 const lines=[5,10,20,60].map(p=>sma(b,p));const bull=lines.every((x,i)=>i===0||lines[i-1]>x);
 let age:number|null=null;if(bull){age=0;for(let e=b.length-1;e>=60;e--){const l=[5,10,20,60].map(p=>sma(b,p,e));if(!l.every((x,i)=>i===0||l[i-1]>x))break;age++;}}
 return {bull,age,slope60:(lines[3]/sma(b,60,b.length-5)-1)*100,spreadPct:(Math.max(...lines)-Math.min(...lines))/lines[2]*100,allRising:[5,10,20,60].every(p=>sma(b,p)>sma(b,p,b.length-3))};
}
