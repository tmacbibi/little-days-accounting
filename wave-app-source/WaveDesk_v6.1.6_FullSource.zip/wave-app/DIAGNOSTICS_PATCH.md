# 波段工作台 v6.1.2 — 來源診斷修補（第 1、2 項）

基準：提交 56903cbb5143f6954ca015e4f9835111009ed1bc（v6.1.2）。**只做診斷，未部署。**
不改：選股／評分／停損規則、轉址跟隨行為（TPEx 仍是 `redirect:'manual'`，任何 3xx 仍視為未取得）、請求標頭、逾時、D1 schema、UI 檔案、PWA 快取版號。

## 這個修補做了什麼
1. **來源診斷紀錄**（新增 `lib/source-diagnostics.ts`，接入 `lib/market.ts` 的 `json()` 與 `lib/feeds.ts` 的 `getJSON()`）
   - 每次抓取後，把狀態碼、種類（ok／empty／redirect／http／timeout／network／parse）、耗時、Location（只留網址＋路徑，丟掉查詢字串與片段）、回應標頭白名單（content-type、server、cf-ray、cf-mitigated、retry-after、content-length）、內文種類（json／html／text／empty）與最多 80 字的 `<title>` 寫入伺服器 log（`console.error('source-diag', …)`）與 D1（`source-diag:<label>`，每個來源只保留最近一次，下一次成功會覆蓋）。
   - 只登錄 13 個固定官方來源（上市 7、上櫃 6）。其他網址（Yahoo、個股日 K）只在「TPEx 網域失敗」時寫 log，不寫 D1。
   - **不記錄**：Cookie／Set-Cookie／Authorization、任何請求標頭、來源回應內文。
   - 所有 `note*` 函式永不丟錯，以 `clone()` 取樣前 2 KB，不影響原本讀取內文的流程。
2. **畫面訊息**：`POST /api/research` 的 `check`／`refresh` 回應，`sourceMessages` 追加「來源名稱：簡短原因（HTTP 狀態碼），最近一次嘗試 MM/DD HH:mm」，並新增結構化欄位 `sourceDiagnostics`。畫面不顯示 Location、標頭或任何來源內文。現有 UI 不需修改（它本來就顯示 `sourceMessages`）。
3. **「已嘗試」與「核對成功」分開**：`update-source-check` 標記改存 `{schema:6, attemptedAt, confirmed}`（schema 不變，舊版可讀）。2 分鐘內不重連時，若任一市場尚未核對，`sourceMessages` 追加「行情來源近期已嘗試（時間），2 分鐘內不重複連線；這不代表核對成功…」，回應新增 `attempt:{at,reused}`。核對成功仍只看 `verifiedMarkets`／`complete`。
4. **探測端點**（新增 `app/api/diagnostics/source/route.ts`）
   - 需登入（`getChatGPTUser()`，未登入回 401）；POST 另檢查 `Origin` 必須同源。
   - **不接受任何網址或參數**；探測網址固定寫在 `probeTargets()`：上市行情 1 個（對照組）＋上櫃 6 個，共 13 次請求（上櫃每個各打 `current`、`plain` 兩組標頭）。
   - 一律 `redirect:'manual'`、8 秒逾時、不帶 Cookie、不跟隨轉址、不寫入行情／研究資料；最多 4 個並行。
   - `current` 與 `lib/market.ts` `json()` 現行標頭相同；`plain` 如實自報身分（`wave-desk-diagnostic/6.1.2`）、不帶 Referer／Accept-Language，**僅為對照觀測，不是修正方案**。
   - 頻率限制（D1 原子 upsert，全站共用）：每 60 秒最多 1 次、每個臺灣日最多 12 次；超過回 429＋`Retry-After`。
   - 結果存 `source-probe-last`；`GET` 同一路徑可讀各來源最近一次詳細紀錄與上次探測結果（同樣需登入）。
5. **文字更正**：`market.ts` 的錯誤訊息由「官方來源轉向錯誤頁，停止重複連線」改為「官方來源回應轉址（3xx），未跟隨；目的地已記錄於伺服器」。只改文字，邏輯相同。另外 `market-source-failed` log 多印來源名稱。

## 修改檔案（`diff -u` 見 `wave-desk-diagnostics.patch`）
| 檔案 | 性質 |
|---|---|
| `lib/source-diagnostics.ts` | 新增 |
| `app/api/diagnostics/source/route.ts` | 新增 |
| `lib/market.ts` | 第 4 行 `json()` 加 note 呼叫與訊息文字；`market-source-failed` log 加名稱；加 import |
| `lib/feeds.ts` | 第 5 行 `getJSON()` 加 note 呼叫（拋出的錯誤文字不變）；加 import |
| `app/api/research/route.ts` | `check` 記錄 attempt／附診斷；`refresh` 附診斷；加 import |
| `scripts/test-source-diagnostics.mjs` | 新增測試 |
| `scripts/test-market-source.mjs`、`scripts/test-update.mjs` | 補替身、加斷言 |

注意：原始碼多為壓成單行的長行，`diff` 會顯示整行替換；請以上表與本節描述對照，實際差異只在上述 note／attempt／diag 呼叫。

## 測試方式
```
pnpm install --frozen-lockfile
node node_modules/typescript/bin/tsc --noEmit
node scripts/test-source-diagnostics.mjs   # 新增：遮蔽、摘要、已嘗試≠成功、固定網址探測、頻率限制（用記憶體 SQLite 跑與正式相同的 SQL）
node scripts/test-market-source.mjs        # 新增斷言：上櫃回 302 仍為「未取得」，狀態碼交給診斷
node scripts/test-update.mjs               # 新增斷言：check 在 2 分鐘內不重連、顯示「近期已嘗試」
node scripts/test-official-bar.mjs && node scripts/test-tracking.mjs && node scripts/test-buy-points.mjs
pnpm build
```

## 在正式 Worker 取得證據
1. 部署後登入網站，在瀏覽器主控台執行：
   `await (await fetch('/api/diagnostics/source',{method:'POST'})).json()`
2. 看 `results[]`：`status`、`detail.location`、`detail.server`、`detail.cfRay`、`detail.cfMitigated`、`detail.bodyKind`／`htmlTitle`，並與 `twse_stock_day_all`（對照組）、`current` 對 `plain` 比較。
3. 按一次 App 的「更新研究」，再 `await (await fetch('/api/diagnostics/source')).json()`，核對正式更新流程各來源的最近一次紀錄（含公告、權息）。
4. 這些是**觀測值，不是結論**。取得 Location 與狀態碼後，再決定：是否跟隨同網域良性轉址、或更換官方管道。若 `plain` 與 `current` 結果不同，也只代表「對這個來源兩組標頭的反應不同」，不等於已確認原因。

## 隱私與保存
- 僅用既有 `store` 表，不需 migration。新增鍵：`source-diag:<label>`、`source-probe-last`、`probe-gate`、`probe-count:<日期>`。
- 詳細紀錄只經登入後的 `/api/diagnostics/source` 讀取；公開的 `check` 回應只含來源名稱、狀態碼、簡短原因、時間。

## 已知限制／待原開發端確認
- 本沙盒無法連外、沒有 wrangler／D1／完整 node_modules：**未實際連線 TPEx、未跑 `pnpm build`、未在 Workers 執行環境驗證**。型別檢查用系統內 TypeScript 6.0.3 搭配 `cloudflare:workers`／`next/*` 型別替身（strict）通過；上述測試以 Node 22 執行（以 `stripTypeScriptTypes` 暫代 `typescript` 轉譯）。`tests/` 目錄下的 modal／render／runtime／research／strategies／pricing-audit 在此環境於修改前即失敗（缺 react／wrangler 或轉譯差異），故未能驗證，與本修補無關但也未被證明無影響。
- 頻率限制依賴 D1 支援 `INSERT … ON CONFLICT … WHERE … RETURNING`（本機以 SQLite 3.45 驗證）；請在正式 D1 確認連打兩次第二次回 429。
- 登入限制沿用 `getChatGPTUser()`。若網站允許任何 ChatGPT 帳號登入，任何登入者都可觸發探測（受上述頻率限制）；如需限定擁有者，需另加使用者白名單（未實作）。
- `lib/revenue.ts` 的上櫃營收來源也經 `getJSON()`，失敗只會寫 log，不會出現在畫面摘要。
- `refresh` 回應同樣附診斷，但 UI 是否顯示以現有程式為準。
- 版本字樣（v6.1.2）與 `public/sw.js` 快取版號未更動，因為沒有改任何前端檔案。

## v6.1.3 正式部署前補強
- 來源內文取樣最多 200ms，取消串流不等待；診斷 D1 寫入最多等待 200ms，探測結果寫入最多等待 500ms。診斷為 best effort，超時可能無持久紀錄。
- GET/POST 詳細診斷僅接受 Sites 已驗證的擁有者 email 白名單，或伺服器設定的短效維護 token。維護 token 只用於本次部署驗證、不在前端或原始碼，逾期自動拒絕。
- POST 必須有與請求網址相同的 Origin，缺少時也拒絕。
- App 維持公開；選股條件、排序、持續追蹤判斷不變。更新進度沿用既有 v6.1.2 儲存鍵，避免丟掉中途進度。
- 新增 test-diagnostic-guards 覆蓋非擁有者、逾期憑證、缺少／跨站 Origin、慢串流與停滯 D1。
