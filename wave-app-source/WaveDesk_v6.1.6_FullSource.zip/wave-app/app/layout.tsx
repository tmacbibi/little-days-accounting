import type {Metadata,Viewport} from 'next';import './globals.css';
export const metadata:Metadata={title:'波段工作台',description:'買點觀察・帶量突破・兩個防守點',manifest:'/manifest.webmanifest',icons:{icon:'/favicon.svg',apple:'/icon-192.png'},appleWebApp:{capable:true,title:'波段工作台',statusBarStyle:'default'}};
export const viewport:Viewport={width:'device-width',initialScale:1,themeColor:'#132b4b'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="zh-Hant"><body>{children}</body></html>}
