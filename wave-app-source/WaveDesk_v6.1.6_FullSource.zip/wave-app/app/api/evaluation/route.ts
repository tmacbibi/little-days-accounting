import {db} from '../../../lib/storage';
import {allHistory,currentMarket} from '../../../lib/research-store';
import {getFeeds} from '../../../lib/feeds';
import {auditHistory} from '../../../lib/report';
import {RULE_VERSION} from '../../../lib/research';
import {evaluateSignal,aggregateEvaluation,SIMULATION} from '../../../lib/evaluation';
export async function GET(){try{
 const [snapshots,hist,market,feeds]=await Promise.all([
  db().prepare("SELECT key,value FROM store WHERE key LIKE 'snapshot:%' ORDER BY key DESC LIMIT 20").all<{key:string,value:string}>(),allHistory(),currentMarket(),getFeeds()
 ]);
 const reports=snapshots.results.map(r=>JSON.parse(r.value)).filter(r=>r.version===RULE_VERSION).sort((a,b)=>a.date.localeCompare(b.date));
 const seen=new Set<string>(),samples:any[]=[],statuses:Record<string,number>={};let missing=0;
 for(const report of reports)for(const r of report.rows){
  if(!r.ready||r.risk.blocked||!r.priority||!['糾結後初次突破','上升途中整理再突破'].includes(r.strategy)||!r.actionsClear||r.abnormalGap||r.dataMismatch||!r.liquid)continue;
  const key=`${r.market}:${r.code}:${r.strategy}:${r.signalDate}`;if(seen.has(key))continue;seen.add(key);
  const q=market.quotes.find((q:any)=>q.code===r.code&&q.market===r.market);if(!q){missing++;continue;}
  const audit=auditHistory(hist[`${r.market}:${r.code}`],q,feeds.actions);if(!audit.checked){missing++;continue;}
  const original=audit.bars.find((b:any)=>b.date===report.date);
  const registry=feeds.actions.markets[r.market];
  if(!original||!registry?.verified||registry.asOf<audit.bars.at(-1)!.date){missing++;continue;}
  const events=registry.events.filter((e:any)=>e.code===r.code);
  const result=evaluateSignal(r,report.date,audit.bars,events,(market.index||[]).map((x:any)=>x.date),original.close/r.price);
  statuses[result.status]=(statuses[result.status]||0)+1;samples.push({strategy:r.strategy,entry:r.entry,potential:r.potential,outcomes:result.outcomes});
 }
 return Response.json({version:RULE_VERSION,asOf:market.quotes.map((q:any)=>q.date).sort().at(-1),snapshots:reports.length,signals:seen.size,missing,statuses,groups:aggregateEvaluation(samples),simulation:SIMULATION,note:'當日買點成立且核對通過候選的前向追蹤，非完整歷史回測；只模擬訊號保存後下一交易日開盤在原有效候選價區的買入。同一訊號只計一次，依每日收盤十日線或原突破K低點先到先出，觀察期滿以收盤結算；不以目標價停利。最多讀取最近20份快照；分組樣本相關，不能視為獨立勝率。'},{headers:{'Cache-Control':'no-store'}});
 }catch{return Response.json({error:'績效追蹤資料尚未完成，請稍後再試'},{status:503});}}
