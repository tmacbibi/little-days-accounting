import {getChatGPTUser} from '../../../chatgpt-auth';
import {env} from 'cloudflare:workers';
import {diagnosticAllowed,sameOrigin} from '../../../../lib/diagnostic-access';
import {claimProbeSlot,probeOfficialSources,readSourceDetails} from '../../../../lib/source-diagnostics';
// 來源診斷（唯讀觀測）。僅限擁有者或短效維護憑證；探測網址固定寫在 lib/source-diagnostics.ts，
// 本路由不接受任何網址或參數，並有全站頻率限制（每 60 秒 1 次、每臺灣日 12 次）。
const noStore={'Cache-Control':'no-store'};
// GET：最近一次各來源的伺服器端詳細紀錄（含 Location 的網址+路徑、回應標頭白名單）與上次探測結果。
export async function GET(req:Request){try{if(!await diagnosticAllowed(req,env,await getChatGPTUser()))return Response.json({error:'僅限擁有者進行診斷'},{status:401,headers:noStore});return Response.json(await readSourceDetails(),{headers:noStore});}catch{return Response.json({error:'診斷紀錄讀取失敗'},{status:503,headers:noStore});}}
// POST：在正式 Worker 內對固定官方網址各打一次（current 為目前標頭；plain 為對照組），不跟隨轉址、不改任何行情或研究資料。
export async function POST(req:Request){try{if(!await diagnosticAllowed(req,env,await getChatGPTUser()))return Response.json({error:'僅限擁有者進行診斷'},{status:401,headers:noStore});
 if(!sameOrigin(req))return Response.json({error:'來源不被允許'},{status:403,headers:noStore});
 const slot=await claimProbeSlot();if(!slot.ok)return Response.json({error:slot.reason==='gap'?'探測過於頻繁，請稍後再試':'今日探測次數已用完',retryAfter:slot.retryAfter},{status:429,headers:{...noStore,'Retry-After':String(slot.retryAfter)}});
 return Response.json(await probeOfficialSources(),{headers:noStore});}catch{return Response.json({error:'探測未完成'},{status:502,headers:noStore});}}
