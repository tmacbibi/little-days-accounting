import fs from 'node:fs';import assert from 'node:assert/strict';import ts from 'typescript';
const source=ts.transpileModule(fs.readFileSync('lib/analysis.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const {analyze,validateBars}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
assert.equal(analyze([]).ready,false);
const actual=JSON.parse(fs.readFileSync('lib/initial-history.json','utf8'));
for(const [k,v] of Object.entries(actual)){const validated=validateBars(v.bars);const result=analyze(validated);assert.equal(result.ready,true,k);assert.equal(result.date,validated.at(-1).date);assert.ok(Number.isFinite(result.ma60));assert.ok(result.stop<result.price||result.state==='趨勢待確認');assert.ok(result.vr>=0);}
assert.throws(()=>validateBars([{date:'2026-09-01',open:100,high:90,low:95,close:100,volume:10}]));
const sample=actual['TW:2330'].bars;assert.throws(()=>validateBars([...sample,sample[0]]));
const flat=Array.from({length:80},(_,i)=>({date:new Date(Date.UTC(2026,5,1+i)).toISOString().slice(0,10),open:100,high:101,low:99,close:100,volume:1000}));const result=analyze(flat);assert.equal(result.pull,false);assert.equal(result.breakout,false);assert.equal(result.hot,false);
console.log(`Analysis checks passed: ${Object.keys(actual).length} actual histories, invalid data rejection, no signals on a flat market.`);
