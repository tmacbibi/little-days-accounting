import fs from 'node:fs';import assert from 'node:assert/strict';import ts from 'typescript';
const tmp='/tmp/wave-research-tests';fs.mkdirSync(tmp,{recursive:true});
for(const name of ['strategies','pricing','instruments','revenue-analysis','research','report','evaluation']){let code=ts.transpileModule(fs.readFileSync(`lib/${name}.ts`,'utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;code=code.replace(/from '\.\/(pricing|instruments)'/g,"from './$1.mjs'").replace("from './strategies'","from './strategies.mjs'").replace("from './research'","from './research.mjs'").replace("from './initial-sectors.json'","from './initial-sectors.json' with {type:'json'}");fs.writeFileSync(`${tmp}/${name}.mjs`,code)}fs.copyFileSync('lib/initial-sectors.json',tmp+'/initial-sectors.json');
const {research,riskStatus,selectPriority}=await import(tmp+'/research.mjs');const {makeReport,getAnalysis,auditHistory}=await import(tmp+'/report.mjs');
const read=x=>JSON.parse(fs.readFileSync(`lib/initial-${x}.json`));const m=read('market'),h=read('history'),risk=read('risk'),actions=read('actions');const feeds={risk,actions};
assert.equal(riskStatus('ANY','TW','2099-01-01',risk).blocked,true,'Future data must not pass old announcements');
const syntheticRisk={asOf:'2026-10-01',markets:{TW:{verified:true,asOf:'2026-10-01',attention:['2222'],warning:['3333'],disposal:[{code:'4444',start:'2026-10-02',end:'2026-10-08'}]}}};
for(const code of ['2222','3333','4444'])assert.equal(riskStatus(code,'TW','2026-10-01',syntheticRisk).blocked,true);
assert.equal(riskStatus('5555','TW','2026-10-01',syntheticRisk).blocked,false);
const report=makeReport(m,h,feeds);assert.equal(report.coverage.preselected,240);assert.ok(report.coverage.analyzed>200);
for(const row of report.rows.filter(x=>x.ready)){
 assert.ok(row.potential>=0&&row.potential<=100);assert.ok(row.entry>=0&&row.entry<=100);if(row.priority)assert.ok(row.plan.entryLow<=row.plan.entryHigh);else{assert.equal(row.plan.entryLow,null);assert.equal(row.plan.entryHigh,null)}
 if(row.risk.blocked)assert.equal(row.entry,0);
 if(row.stage==='已明顯拉升')assert.ok(row.entry<=35);
 if(row.rewardRisk<1)assert.ok(row.entry<=49);
 if(row.priority){assert.ok(row.rewardRisk>=1.5);assert.ok(row.price>=row.plan.entryLow&&row.price<=row.plan.entryHigh);assert.equal(row.risk.blocked,false);assert.equal(row.stage,'剛轉強');}
}
const q=m.quotes.find(x=>x.code==='2303'),raw=h['TW:2303'];const a=getAnalysis(raw,q,m,feeds);assert.equal(a.entry,49,'A strong trend with insufficient reward/risk should not be scored as a good entry');assert.equal(a.priority,false);
const bad=getAnalysis(raw,q,m,{risk:{markets:{}},actions});assert.equal(bad.entry,0);assert.equal(bad.priority,false);
const stale=getAnalysis(raw,{...q,date:'2099-01-01'},m,feeds);assert.equal(stale.dataMismatch,true);assert.equal(stale.priority,false);
const noBenchmark=getAnalysis(raw,q,{index:[]},feeds);assert.equal(noBenchmark.potentialParts[3].score,0);
const audit=auditHistory({bars:[{date:'2026-06-01',open:100,high:102,low:99,close:100,volume:10},{date:'2026-06-02',open:90,high:91,low:89,close:90,volume:11}],source:'raw'},q,{markets:{TW:{verified:true,fromDate:'2026-06-01',asOf:'2026-06-02',events:[{code:q.code,date:'2026-06-02',factor:.9,kind:'息'}]}}});assert.equal(audit.bars[0].close,90);assert.equal(audit.bars[1].close,90);assert.equal(audit.bars[0].volume,10);
const fake=(code,sector,ranking)=>({ready:true,priority:true,code,sector,ranking,entry:80});const picked=selectPriority([fake('1000','半導體',99),fake('1001','半導體',98),fake('1002','半導體',97),fake('1003','金融',96)]);assert.equal(picked.filter(x=>x.sector==='半導體').length,2);assert.equal(picked.length,3);
const early=Array.from({length:80},(_,i)=>{const close=95+i*.2;return {date:new Date(Date.UTC(2026,6,14+i)).toISOString().slice(0,10),open:close-.1,high:close+.3,low:close-.4,close,volume:1000000}});const closes=[109,109.5,110,110.5,110,109.8,109.5,109.8,110,111];for(let i=70;i<80;i++){early[i]={...early[i],open:closes[Math.max(0,i-71)],high:closes[i-70]+.3,low:closes[i-70]-.4,close:closes[i-70]};if(early[i].open>early[i].high)early[i].high=early[i].open+.2;}early[72].high=118;early[79].open=110;early[79].volume=1600000;const ed=early.at(-1).date;const ec={quote:{code:'9999',name:'Synthetic test',market:'TW',date:ed,close:111},adjusted:true,risk:{markets:{TW:{verified:true,asOf:ed,attention:[],warning:[],disposal:[]}}}};assert.equal(research(early,ec).priority,true,'A confirmed early signal with sufficient upside can qualify');
assert.ok(Buffer.byteLength(JSON.stringify(report))<950000,'Snapshot should fit comfortably in storage');
console.log(`Research checks passed: ${report.coverage.analyzed} actual stocks, risk exclusions, late entry caps, reward/risk gates, corporate actions, stale data and industry concentration.`);

const {feasibleEntry,netRewardRisk}=await import(tmp+'/pricing.mjs');const {isOrdinary}=await import(tmp+'/instruments.mjs');const {revenueSummary}=await import(tmp+'/revenue-analysis.mjs');
assert.equal(isOrdinary({code:'0050',market:'TW'}),false);assert.equal(isOrdinary({code:'9999',market:'TW'}),false);assert.equal(isOrdinary(q),true);assert.ok(report.quotes.every(isOrdinary));
assert.equal(a.plan.entryLow,null);assert.equal(a.plan.candidateHigh,null);assert.equal(a.plan.evidence.support.date,'2026-09-29');assert.equal(a.plan.evidence.support.value,151.5);assert.equal(a.plan.stop,149);assert.ok(a.commentary.reason.includes('報酬'));assert.ok(a.plan.rewardRisk<a.plan.grossRewardRisk);
const bounds=feasibleEntry(100,102,95,115);assert.ok(bounds.high>=bounds.low);assert.ok(netRewardRisk(bounds.high,95,115)>=1.5);assert.equal(feasibleEntry(158.5,162.5,149,168).high,null);
const adjustedAudit=auditHistory({bars:raw.bars,adjusted:true,source:'adjusted'},q,actions);assert.equal(adjustedAudit.bars[0].close,raw.bars[0].close);
const seed=JSON.parse(fs.readFileSync('lib/initial-revenue.json'));const revenue=revenueSummary(seed.markets.TW.rows.filter(r=>r.code==='2303'),'2026-10-02',seed.fetched);assert.equal(revenue.status,'營收支持');assert.equal(revenue.latest.month,'2026-08');assert.equal(revenue.weighted,false);assert.ok(revenue.rolling3>0);assert.equal(revenue.rows.length,6);
const missing=revenueSummary(revenue.rows.filter(r=>r.month!=='2026-07'),'2026-10-02',seed.fetched);assert.equal(missing.rolling3,null);assert.equal(missing.status,'資料不足');assert.equal(revenueSummary([],'2026-10-02',seed.fetched).status,'資料不足');assert.equal(revenueSummary(revenue.rows,'2027-01-01',seed.fetched).status,'資料待更新');
assert.deepEqual(getAnalysis(raw,q,m,feeds),getAnalysis(raw,q,m,{...feeds,revenue}),'Revenue does not alter technical scores, prices or gates');
console.log('New checks passed: net-cost candidate ranges, explicit no-entry, dated structural support, affirmative ordinary-stock roster and independent revenue context.');

const unverifiedAdjusted=getAnalysis({...raw,adjusted:true},q,m,{risk,actions:{markets:{}}});assert.equal(unverifiedAdjusted.actionsClear,false);assert.equal(unverifiedAdjusted.priority,false);
