import fs from 'node:fs';import ts from 'typescript';import assert from 'node:assert/strict';
const tmp=fs.mkdtempSync('/tmp/wave-pricing-audit-');
try{
 const code=ts.transpileModule(fs.readFileSync('lib/pricing.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;fs.writeFileSync(tmp+'/pricing.mjs',code);
 const {priceDown,priceUp,snapSourcePrice,structuralSupport,resistanceZones,priceEvidence,feasibleEntry,netRewardRisk,COSTS}=await import(tmp+'/pricing.mjs');
 for(const [raw,want] of [[193.49998461815306,193.5],[74.0999984741211,74.1],[1609.9999954458185,1610],[9.999999,10],[49.999999,50],[99.999999,100],[499.999999,500],[999.999999,1000]]){assert.equal(priceDown(raw,true),want);assert.equal(priceUp(raw,true),want);}
 assert.equal(snapSourcePrice(193.499),193.499,'A genuine off-grid adjusted level must stay off-grid');assert.equal(priceDown(193.499,true),193);
 const e=100-1e-6,stop=95,target=2.5*e*(1+COSTS.buy)/(1-COSTS.sell)-1.5*stop;const bounds=feasibleEntry(99,105,stop,target);assert.equal(bounds.high,99.9,'Cost-derived ceiling must not be snapped upward');assert.ok(netRewardRisk(bounds.high,stop,target)>=1.5);assert.ok(netRewardRisk(100,stop,target)<1.5);
 const bars=Array.from({length:25},(_,i)=>({date:`2026-09-${String(i+1).padStart(2,'0')}`,open:99,high:100,low:99,close:99.5,volume:1000000}));bars[8].low=90;bars[16].low=96;
 assert.equal(structuralSupport(bars,20,'糾結突破').value,90);assert.equal(structuralSupport(bars,20,'回檔再上').value,96);
 const c=(index,value=110)=>({index,date:bars[index].date,value,type:'已確認歷史高點',confirmed:bars[index+2].date});
 let zones=resistanceZones([c(4),c(5)],bars,2);assert.equal(zones[0].testCount,1,'Adjacent plateau peaks are one test');
 zones=resistanceZones([c(4),c(10)],bars,2);assert.equal(zones[0].testCount,2,'Separated peaks with intervening retracement are independent tests');
 const shallow=bars.map(b=>({...b,low:109.8}));assert.equal(resistanceZones([c(4),c(10)],shallow,2)[0].testCount,1,'Elapsed time alone cannot confirm a new test');
 assert.equal(resistanceZones([{...c(4),confirmed:null,type:'前20日整理區上緣'}],bars,2)[0].testCount,0,'Unconfirmed box edges are not confirmed tests');
 const episode={index:20,trigger:101,atr:2,strategy:'糾結突破'};const prefix=bars.slice(0,21);episode.initialEvidence=priceEvidence(prefix,2,101,episode,[],[],99,99);const initial=structuredClone(episode.initialEvidence);const later=bars.map(b=>({...b}));later[21].low=80;
 const after=priceEvidence(later,10,101,episode,[],[],98,99);assert.deepEqual(after.support,initial.support);assert.equal(after.stop,initial.stop);assert.equal(after.planATR,2);assert.equal(after.buffer,.7);assert.ok(after.signalInvalidation.note.includes('兩者不同'));
 const report=JSON.parse(fs.readFileSync('lib/initial-report.json'));for(const row of report.rows.filter(r=>r.ready)){const p=row.plan;assert.equal(p.target1,p.evidence.resistance.value);assert.equal(p.target2,p.evidence.target2Basis.value);for(const r of [p.evidence.resistance,p.evidence.target2Basis])if(r.upper!=null)assert.ok(r.value<=r.upper+1e-8);}
 console.log('Pricing audit passed: Float32/tick boundaries, genuine adjusted levels, conservative RR ceiling, causal support windows, independent pressure tests, frozen initial support/stop and matching target provenance.');
}finally{fs.rmSync(tmp,{recursive:true,force:true})}
