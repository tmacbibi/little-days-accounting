import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import ts from 'typescript';import assert from 'node:assert/strict';
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'wave-update-'));
const emit=(name,source)=>fs.writeFileSync(path.join(dir,name+'.mjs'),ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText.replace(/from ['"](?:\.\.\/)*lib\/([^'"]+)['"]/g,"from './$1.mjs'"));
try{
const src=fs.readFileSync('lib/market.ts','utf8');emit('latest',src.slice(src.indexOf('export function latestQuotes')));const {latestQuotes}=await import(`${dir}/latest.mjs`);
assert.deepEqual(latestQuotes([{market:'TWO',code:'1',date:'2026-10-01'},{market:'TWO',code:'1',date:'2026-10-02'},{market:'TWO',code:'1',date:'2026-10-02'},{market:'TW',code:'2',date:'2026-10-01'}]).map(x=>x.date),['2026-10-01','2026-10-02']);
emit('update-status',fs.readFileSync('lib/update-status.ts','utf8'));
const {updateStatus}=await import(`${dir}/update-status.mjs`);const q=[{market:'TW',code:'2399',date:'2026-10-02',close:51.2,volume:8687000}];const m={quotes:[...q,{market:'TWO',code:'6147',date:'2026-10-02'}],messages:[],sessionVerified:true,expectedSession:'2026-10-02',confirmed:{TW:true,TWO:true}};const h={'TW:2399':{bars:[{date:'2026-10-02'}]}};const f={risk:{markets:{TW:{verified:true,asOf:'2026-10-02'}}},actions:{markets:{TW:{verified:true,asOf:'2026-10-02'}}}};f.risk.markets.TWO={verified:true,asOf:'2026-10-02'};f.actions.markets.TWO={verified:true,asOf:'2026-10-02'};const state=updateStatus(q,h,m,f,null);assert.equal(state.missing.length,0);assert.equal(state.availableComplete,true);assert.equal(updateStatus(q,h,m,f,{inputKey:'other-device-tracked-list'}).availableComplete,true);assert.equal(updateStatus(q,h,m,f,{inputKey:state.inputKey}).complete,true);assert.equal(updateStatus(q,{},m,f,{inputKey:state.inputKey}).missing.length,1);assert.equal(updateStatus(q,h,m,{...f,risk:{markets:{}}},{inputKey:state.inputKey}).complete,false);assert.equal(updateStatus([{...q[0],date:'2026-10-05'}],h,m,f,{inputKey:state.inputKey}).complete,false);
assert.equal(updateStatus(q,h,{...m,expectedSession:'2026-10-05'},f,{inputKey:state.inputKey}).complete,false);assert.equal(updateStatus(q,h,{...m,confirmed:{TW:true,TWO:false}},f,{inputKey:state.inputKey}).complete,false);assert.equal(updateStatus(q,h,{...m,sessionVerified:false},f,{inputKey:state.inputKey}).complete,false);
// A failed OTC source must neither block a completed TW update nor label both markets current.
const partial={...m,confirmed:{TW:true,TWO:false}};
const partialFeeds={risk:{markets:{TW:f.risk.markets.TW}},actions:{markets:{TW:f.actions.markets.TW}}};
const partialState=updateStatus([...q,{market:'TWO',code:'6147',date:'2026-10-01'}],h,partial,partialFeeds,null);
assert.equal(partialState.total,1);assert.equal(partialState.feedsNeeded,false);
const completedPartial=updateStatus(q,h,partial,partialFeeds,{inputKey:partialState.inputKey});
assert.equal(completedPartial.availableComplete,true);assert.equal(completedPartial.complete,false);
assert.equal(completedPartial.verifiedMarkets.TWO,false);
assert.equal(updateStatus(q,{},partial,partialFeeds,{inputKey:partialState.inputKey}).availableComplete,false);
emit('instruments','export const isOrdinary=()=>true;');emit('research',"export const RULE_VERSION='buy-points-6.0';");
emit('storage',"export const read=async(k)=>globalThis.__read?globalThis.__read(k):({updated:Date.now(),data:{version:'buy-points-6.0'}});export const save=async(k,v)=>{(globalThis.__saved??=[]).push([k,v])};export const db=()=>({});");
emit('source-diagnostics',"export const readSourceSummaries=async()=>globalThis.__diag||[];export const summaryLines=l=>l.filter(x=>x.kind!=='ok').map(x=>x.name+':'+x.reason);export const attemptNotice=(at,reused,some)=>reused&&some&&at?'近期已嘗試；不代表核對成功':'';");
emit('revenue',"export const getRevenue=async()=>({});export const refreshRevenue=async()=>({messages:['營收失敗']});");
emit('feeds',"export const getFeeds=async()=>({});export const refreshFeeds=async()=>({risk:{markets:{TW:{error:'failed'},TWO:{}}},actions:{markets:{TW:{},TWO:{}}}});");
emit('report',"export const getAnalysis=()=>({});export const auditHistory=()=>({});export const preliminary=q=>q;");
emit('research-store',"export const currentMarket=async()=>({quotes:[{code:'1',market:'TW',date:'2026-10-02'}]});export const getCurrent=async()=>({});export const buildCurrent=async()=>({rebuilt:true});export const allHistory=async()=>({});export const archiveReport=async()=>{};");
emit('market',"export let calls=0;export const market=async()=>{calls++;return {fetched:'new',quotes:[{market:'TW',date:'2026-10-02'}]}};export const history=async()=>({bars:[{date:'2026-10-01'}],warning:'更新失敗'});");
emit('route',fs.readFileSync('app/api/research/route.ts','utf8').replace("import('../../../lib/report')","import('./report.mjs')"));const {POST}=await import(`${dir}/route.mjs`);const call=async x=>{const r=await POST(new Request('https://example.test/api/research',{method:'POST',body:JSON.stringify(x)}));return {status:r.status,data:await r.json()}};
assert.equal((await call({action:'refresh'})).data.marketFetched,'new');assert.equal((await import(`${dir}/market.mjs`)).calls,1);
const scan=await call({action:'scan',offset:0});assert.equal(scan.data.ok,0);assert.equal(scan.data.stale,1);assert.equal(scan.data.next,1);
assert.equal((await call({action:'scan',offset:0,queueKey:'changed'})).status,409);
assert.equal((await call({action:'rebuild'})).data.rebuilt,true);
assert.equal((await call({action:'feeds'})).data.messages.length,1);assert.equal((await call({action:'revenue'})).data.messages.length,1);
// 「近期已嘗試」不得被當成「核對成功」；診斷摘要只以來源名稱＋狀態碼＋簡短原因進入畫面訊息。
const marketMod=await import(`${dir}/market.mjs`);globalThis.__diag=[{label:'tpex_mainboard_quotes',name:'上櫃行情',kind:'redirect',status:302,reason:'收到轉址（302）',at:'x'}];
globalThis.__read=k=>k==='update-source-check'?{updated:Date.now()-30000,data:{schema:6}}:{updated:Date.now(),data:{version:'buy-points-6.0'}};
const callsBefore=marketMod.calls;const reused=(await call({action:'check'})).data;
assert.equal(marketMod.calls,callsBefore,'2 分鐘內不重複連線');assert.equal(reused.attempt.reused,true);assert.ok(reused.attempt.at);assert.equal(reused.verifiedMarkets.TW,false);
assert.ok(reused.sourceMessages.some(x=>x.includes('近期已嘗試')&&x.includes('不代表核對成功')));assert.ok(reused.sourceMessages.some(x=>x==='上櫃行情:收到轉址（302）'));assert.equal(reused.sourceDiagnostics.length,1);
globalThis.__read=k=>({updated:Date.now(),data:{version:'buy-points-6.0'}});globalThis.__saved=[];
const fresh=(await call({action:'check'})).data;assert.equal(marketMod.calls,callsBefore+1);assert.equal(fresh.attempt.reused,false);assert.ok(!fresh.sourceMessages.some(x=>x.includes('近期已嘗試')));
const marker=globalThis.__saved.find(x=>x[0]==='update-source-check')[1];assert.equal(marker.schema,6);assert.ok(marker.attemptedAt>0);
delete globalThis.__read;delete globalThis.__diag;
console.log('PASS: newest-session deduplication, fresh market fetch despite recent report, stale history not counted as success, changed queue rejected, explicit source warnings, rebuild bypasses stale cache.');
}finally{fs.rmSync(dir,{recursive:true,force:true})}
