import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import ts from 'typescript';import assert from 'node:assert/strict';
const {DatabaseSync}=await import('node:sqlite');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'wave-diag-'));
try{
// D1 以記憶體 SQLite 模擬（含 RETURNING / ON CONFLICT ... WHERE，與正式頻率限制 SQL 相同）。
const sql=new DatabaseSync(':memory:');sql.exec('CREATE TABLE store (key TEXT PRIMARY KEY,value TEXT,updated INTEGER)');
const stmt=q=>{let args=[];const st=sql.prepare(q);const o={bind:(...a)=>{args=a;return o},first:async()=>st.get(...args)??null,all:async()=>({results:st.all(...args)}),run:async()=>st.run(...args)};return o};
const db=()=>({prepare:stmt});
const read=async k=>{const r=await db().prepare('SELECT value, updated FROM store WHERE key=?').bind(k).first();return r?{data:JSON.parse(r.value),updated:r.updated}:null};
const save=async(k,d)=>{await db().prepare('INSERT INTO store (key,value,updated) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated').bind(k,JSON.stringify(d),Date.now()).run()};
globalThis.__store={db,read,save};
let source=fs.readFileSync('lib/source-diagnostics.ts','utf8').replace("import {db,read,save} from './storage';","const {db,read,save}=globalThis.__store;");
const file=path.join(dir,'diag.mjs');fs.writeFileSync(file,ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText);
const d=await import(file);
const rows=()=>sql.prepare("SELECT key,value FROM store WHERE key LIKE 'source-diag:%'").all();
const errors=[];const origError=console.error;console.error=(...a)=>errors.push(a.join(' '));

// 1) 轉址：只記狀態碼、Location 的網址+路徑、標頭白名單與內文種類；不含 Cookie、查詢字串、內文
const tpexQuotes='https://www.tpex.org.tw/openapi/v1/tpex_mainboard_quotes';
const redirect=new Response('<html><head><title>Access Denied</title></head><body>SECRET-BODY</body></html>',{status:302,headers:{Location:'https://www.tpex.org.tw/errors/x.html?token=SECRET-TOKEN#frag','Set-Cookie':'sid=SECRET-COOKIE','Content-Type':'text/html','CF-RAY':'abc123-TPE','Server':'cloudflare'}});
await d.noteSourceHttp(tpexQuotes,redirect,Date.now()-50);
let saved=(await read('source-diag:tpex_mainboard_quotes')).data;
assert.equal(saved.kind,'redirect');assert.equal(saved.status,302);assert.equal(saved.detail.location,'https://www.tpex.org.tw/errors/x.html');
assert.equal(saved.detail.bodyKind,'html');assert.equal(saved.detail.htmlTitle,'Access Denied');assert.equal(saved.detail.cfRay,'abc123-TPE');
const dump=JSON.stringify(rows())+errors.join('\n');
for(const secret of ['SECRET-COOKIE','SECRET-TOKEN','SECRET-BODY','set-cookie','Set-Cookie','sid='])assert.ok(!dump.includes(secret),'leaked '+secret);
assert.ok(errors.some(e=>e.startsWith('source-diag ')),'server log line written');

// 2) 畫面摘要只含來源、狀態碼、簡短原因，不含 Location/標頭
const lines=d.summaryLines(await d.readSourceSummaries());
assert.equal(lines.length,1);assert.match(lines[0],/上櫃行情：收到轉址（302）.*（HTTP 302）/);assert.ok(!/errors\/x|cloudflare|abc123|Access Denied/.test(lines[0]));

// 3) 成功會覆蓋舊失敗；空陣列不算正常；未登錄來源不寫 D1
await d.noteSourceOk(tpexQuotes,new Response('[]'),Date.now(),[]);
assert.equal((await read('source-diag:tpex_mainboard_quotes')).data.kind,'empty');assert.match(d.summaryLines(await d.readSourceSummaries())[0],/回應為空陣列/);
await d.noteSourceOk(tpexQuotes,new Response('[1]'),Date.now(),[1]);
assert.equal(d.summaryLines(await d.readSourceSummaries()).length,0);
const before=rows().length;await d.noteSourceOk('https://query1.finance.yahoo.com/v8/finance/chart/2330.TW?range=6mo',new Response('{}'),Date.now(),{});await d.noteSourceHttp('https://query1.finance.yahoo.com/v8/finance/chart/2330.TW',new Response('x',{status:500}),Date.now());assert.equal(rows().length,before);
errors.length=0;await d.noteSourceHttp('https://www.tpex.org.tw/www/zh-tw/afterTrading/tradingStock?code=6147',new Response(null,{status:301,headers:{Location:'/a?b=1'}}),Date.now());assert.equal(rows().length,before);assert.equal(errors.length,1);

// 4) 逾時／網路錯誤／非 JSON
const timeout=new Error('The operation was aborted due to timeout');timeout.name='TimeoutError';await d.noteSourceError(tpexQuotes,timeout,Date.now());assert.equal((await read('source-diag:tpex_mainboard_quotes')).data.kind,'timeout');
await d.noteSourceError(tpexQuotes,new TypeError('fetch failed'),Date.now());assert.equal((await read('source-diag:tpex_mainboard_quotes')).data.kind,'network');
await d.noteSourceParse(tpexQuotes,new Response('x',{headers:{'content-type':'text/html'}}),Date.now(),'<html><title>t</title>');assert.equal((await read('source-diag:tpex_mainboard_quotes')).data.detail.bodyKind,'html');

// 5)「已嘗試」不等於「核對成功」
assert.match(d.attemptNotice(Date.now(),true,true),/近期已嘗試.*不代表核對成功/);assert.equal(d.attemptNotice(Date.now(),true,false),'');assert.equal(d.attemptNotice(Date.now(),false,true),'');

// 6) 探測：固定網址、不跟隨轉址、不送 Cookie、current/plain 兩組標頭
const targets=d.probeTargets(Date.UTC(2026,9,8,10));assert.equal(targets.length,11);
for(const t of targets)assert.ok(['openapi.twse.com.tw','www.tpex.org.tw'].includes(new URL(t.url).host),t.url);
assert.match(targets.at(-1).url,/startDate=2026\/10\/01&endDate=2026\/10\/08/);
const calls=[];globalThis.fetch=async(url,init)=>{calls.push({url,init});return url.includes('tpex_mainboard_quotes')?new Response(null,{status:302,headers:{Location:'https://www.tpex.org.tw/e?x=1'}}):new Response('[{"a":1}]',{headers:{'content-type':'application/json'}})};
const probe=await d.probeOfficialSources(Date.UTC(2026,9,8,10));
assert.equal(calls.length,17);assert.ok(calls.every(c=>c.init.redirect==='manual'&&!Object.keys(c.init.headers).some(k=>/cookie|authorization/i.test(k))));
const plain=calls.find(c=>c.init.headers['User-Agent'].startsWith('wave-desk-diagnostic'));assert.ok(plain&&!('Referer' in plain.init.headers));
const cur=calls.find(c=>c.url.includes('tpex_mainboard_quotes')&&c.init.headers.Referer);assert.equal(cur.init.headers.Referer,'https://www.tpex.org.tw/');
const r302=probe.results.filter(r=>r.label==='tpex_mainboard_quotes');assert.equal(r302.length,2);assert.ok(r302.every(r=>r.kind==='redirect'&&r.status===302&&r.detail.location==='https://www.tpex.org.tw/e'));
assert.ok(probe.results.filter(r=>r.label!=='tpex_mainboard_quotes').every(r=>r.kind==='ok'));assert.equal((await read('source-probe-last')).data.results.length,17);
assert.ok(!(await read('source-diag:tpex_mainboard_quotes')).data.detail.location,'探測不覆蓋正式更新的紀錄');

// 7) 頻率限制：每 60 秒 1 次、每臺灣日 12 次
const t0=Date.UTC(2026,9,8,2,0,0);
assert.equal((await d.claimProbeSlot(t0)).ok,true);
const gap=await d.claimProbeSlot(t0+30000);assert.equal(gap.ok,false);assert.equal(gap.reason,'gap');assert.equal(gap.retryAfter,30);
assert.equal((await d.claimProbeSlot(t0+60000)).ok,true);
let n=2;for(let i=2;i<12;i++){assert.equal((await d.claimProbeSlot(t0+i*61000)).ok,true);n++}
const daily=await d.claimProbeSlot(t0+12*61000);assert.equal(daily.ok,false);assert.equal(daily.reason,'daily');
assert.equal((await d.claimProbeSlot(t0+86400000+61000*13)).ok,true,'隔天重新計算');
console.error=origError;
console.log('PASS: redacted server diagnostics (no cookies/query/body), screen summaries, attempted-vs-verified wording, fixed-URL no-follow probe, 60s/12-per-day rate limit.');
}finally{fs.rmSync(dir,{recursive:true,force:true})}
