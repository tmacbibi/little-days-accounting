import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import ts from 'typescript';import assert from 'node:assert/strict';
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'wave-bar-'));try{const file=path.join(dir,'bar.mjs');fs.writeFileSync(file,ts.transpileModule(fs.readFileSync('lib/official-bar.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText);const {appendOfficialBar}=await import(file);
const h={bars:[{date:'2026-10-07',close:100}],adjusted:true,source:'Yahoo',warning:'old'};
const q={market:'TW',code:'6239',date:'2026-10-08',open:101,high:104,low:100,close:103,change:3,volume:3000000};const a={verified:true,asOf:q.date,events:[]};
assert.equal(appendOfficialBar(h,q,a).bars.at(-1).close,103);assert.equal(appendOfficialBar(h,{...q,market:'TWO'},a).bars.at(-1).close,103);assert.equal(appendOfficialBar(h,{...q,market:'UNKNOWN'},a),null);assert.equal(appendOfficialBar(h,q,a).warning,undefined);
assert.equal(appendOfficialBar(h,{...q,date:'2026-10-09'}, {...a,asOf:'2026-10-09'}),null);
assert.equal(appendOfficialBar(h,q,{...a,events:[{code:q.code,date:q.date}]}),null);
assert.equal(appendOfficialBar(h,q,{...a,asOf:'2026-10-07'}),null);
assert.equal(appendOfficialBar(h,{...q,change:10},a),null);assert.equal(appendOfficialBar(h,{...q,low:102},a),null);
assert.equal(appendOfficialBar({...h,bars:[{date:'2026-10-02',close:100}]},{...q,date:'2026-10-05'},{...a,asOf:'2026-10-05'}).bars.length,2);
console.log('PASS: contiguous verified official bar appended, gaps/dividends/stale registry/price discontinuities/invalid OHLC require full history.');}finally{fs.rmSync(dir,{recursive:true,force:true})}
