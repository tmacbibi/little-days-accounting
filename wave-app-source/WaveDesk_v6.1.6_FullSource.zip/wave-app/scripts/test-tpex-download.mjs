import fs from 'node:fs';import ts from 'typescript';import assert from 'node:assert/strict';
const s=fs.readFileSync('lib/tpex-download.ts','utf8').replace(/import \{noteSourceError[^;]+;/,"const noteSourceError=async()=>{},noteSourceHttp=async()=>{},noteSourceParse=async()=>{},noteSourceOk=async()=>{};");
const d=await import('data:text/javascript;base64,'+Buffer.from(ts.transpileModule(s,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText).toString('base64'));
const header='資料日期,代號,名稱,收盤,漲跌,開盤,最高,最低,成交股數,成交金額\n';
const rows=Array.from({length:101},(_,i)=>`"1151008","${3000+i}","測試,股",51,1,50,52,49,"3,000,000",153000000`).join('\r\n');
const quotes=d.parseTpexQuotes(header+rows);assert.equal(quotes.length,101);assert.equal(quotes[0].volume,3000000);assert.equal(quotes[0].date,'2026-10-08');assert.equal(quotes[0].name,'測試,股');assert.equal(quotes[0].open,50);assert.throws(()=>d.parseTpexQuotes('<html>error</html>'));assert.throws(()=>d.parseTpexQuotes(header+rows.replace('1151008','1151007')));assert.throws(()=>d.parseCSV('"truncated'));
console.log('PASS: official CSV columns, OHLC, exact volume units, mixed-date rejection and incomplete CSV rejection');
