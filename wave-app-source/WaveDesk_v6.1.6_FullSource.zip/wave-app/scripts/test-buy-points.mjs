import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import ts from 'typescript';import assert from 'node:assert/strict';
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'wave-test-'));
try {
 for(const name of ['research','pricing','evaluation']){const code=ts.transpileModule(fs.readFileSync(`lib/${name}.ts`,'utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText.replace("from './pricing'","from './pricing.mjs'");fs.writeFileSync(`${dir}/${name}.mjs`,code)}
 const {research,selectPriority}=await import(`${dir}/research.mjs`);const fixtures=JSON.parse(fs.readFileSync('scripts/fixtures/confirmed-cases.json'));
 const ctx=f=>({quote:{code:f.code,name:f.name,market:f.market,date:f.date,close:f.bars.at(-1).close},sector:'測試產業',adjusted:true,eventsChecked:true,risk:{markets:{[f.market]:{verified:true,asOf:f.date,disposal:[],attention:[],warning:[],sources:[]}}}});
 const results=fixtures.map(f=>research(f.bars,ctx(f)));console.log(results.map(a=>({code:a.code,signal:a.signalDate,stage:a.stage,type:a.strategy,low:a.plan.signalLow,ma10:a.ma10,priority:a.priority,bias5:a.bias5})));
 for(let i=0;i<fixtures.length;i++){const f=fixtures[i],a=results[i];assert.equal(a.signalDate,f.date);assert.equal(a.technical,true);assert.equal(a.priority,true);assert.equal(a.plan.signalLow,f.bars.at(-1).low);assert.equal(a.plan.stop,Math.max(a.ma10,a.plan.signalLow));assert.equal(a.plan.exitRule,'MA10_OR_SIGNAL_LOW');assert.equal(a.plan.entryHigh,null);assert.equal(a.plan.entryLow,null)}
 assert.equal(results[0].strategy,'糾結後初次突破');assert.equal(results[1].strategy,'上升途中整理再突破');assert(results[0].bias5>5&&results[0].priority);
 const f=fixtures[0];const lowVol=structuredClone(f.bars);lowVol.at(-1).volume=2999000;assert.equal(research(lowVol,ctx(f)).technical,false);
 const lowRatio=structuredClone(f.bars);lowRatio.at(-2).volume=lowRatio.at(-1).volume/1.99;assert.equal(research(lowRatio,ctx(f)).technical,false);
 assert.equal(research(f.bars,{...ctx(f),risk:undefined}).priority,false);
 assert.equal(research(f.bars,{...ctx(f),sector:'金融保險'}).priority,false);
 for(const code of ['2002','1101'])assert.equal(research(f.bars,{...ctx(f),quote:{...ctx(f).quote,code}}).priority,false);
 assert.equal(research(f.bars,{...ctx(f),quote:{...ctx(f).quote,date:'2025-09-18'}}).priority,false);
 assert.equal(research(f.bars,{...ctx(f),eventsChecked:false}).priority,false);
 const lots=Array.from({length:5},(_,i)=>({...results[0],code:String(9000+i),entry:90-i,potential:60+i}));assert.deepEqual(selectPriority(lots).map(a=>a.code),['9000','9001','9002']);
 const {evaluateSignal}=await import(`${dir}/evaluation.mjs`);
 const prior=Array.from({length:10},(_,i)=>({date:`2025-01-${String(i+1).padStart(2,'0')}`,open:100,high:102,low:98,close:100,volume:4000000}));
 const future=Array.from({length:20},(_,i)=>({date:`2025-01-${String(i+11).padStart(2,'0')}`,open:101,high:105,low:99,close:102,volume:4000000}));
 const row={plan:{candidateLow:100,candidateHigh:103,stop:99,signalLow:90,target1:null,exitRule:'MA10_OR_SIGNAL_LOW'}};
 assert.equal(evaluateSignal(row,'2025-01-10',[...prior,...future]).outcomes[0].reason,'期末收盤');
 const fallen=structuredClone(future);fallen[1].close=99;
 assert.equal(evaluateSignal(row,'2025-01-10',[...prior,...fallen]).outcomes[0].exitDate,'2025-01-12');
 const lowBreak=structuredClone(future);lowBreak[1].close=101;
 assert.equal(evaluateSignal({plan:{...row.plan,signalLow:101.5}},'2025-01-10',[...prior,...lowBreak]).outcomes[0].exitDate,'2025-01-12');
 console.log('PASS: 3 historical signals, 2 pattern labels, dual support prices, volume thresholds, exclusions, data gates, no MA5 cutoff, top-three order.');
} finally{fs.rmSync(dir,{recursive:true,force:true})}
