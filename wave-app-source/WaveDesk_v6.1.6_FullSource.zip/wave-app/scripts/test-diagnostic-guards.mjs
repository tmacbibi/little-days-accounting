import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import ts from 'typescript';import assert from 'node:assert/strict';
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'wave-guards-'));
const load=async(name,source)=>{const p=path.join(dir,name+'.mjs');fs.writeFileSync(p,ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText);return import(p)};
try{
const access=await load('access',fs.readFileSync('lib/diagnostic-access.ts','utf8'));const cfg={DIAGNOSTICS_OWNER_EMAIL:'owner@example.com',DIAGNOSTICS_ADMIN_TOKEN:'valid-test-token',DIAGNOSTICS_ADMIN_EXPIRES:new Date(Date.now()+60000).toISOString()};
const req=(headers={})=>new Request('https://site.example/api/diagnostics/source',{method:'POST',headers});
assert.equal(await access.diagnosticAllowed(req(),cfg,null),false);
assert.equal(await access.diagnosticAllowed(req(),cfg,{userId:'other',email:'other@example.com'}),false);
assert.equal(await access.diagnosticAllowed(req(),cfg,{userId:'owner',email:'owner@example.com'}),true);
assert.equal(await access.diagnosticAllowed(req({'x-wave-diagnostic-token':'valid-test-token'}),cfg,null),true);
assert.equal(await access.diagnosticAllowed(req({'x-wave-diagnostic-token':'wrong'}),cfg,null),false);
assert.equal(await access.diagnosticAllowed(req({'x-wave-diagnostic-token':'valid-test-token'}),{...cfg,DIAGNOSTICS_ADMIN_EXPIRES:'2000-01-01'},null),false);
assert.equal(access.sameOrigin(req()),false);assert.equal(access.sameOrigin(req({origin:'https://other.example'})),false);assert.equal(access.sameOrigin(req({origin:'https://site.example'})),true);
globalThis.__store={db:()=>{},read:async()=>null,save:async()=>new Promise(()=>{})};
const d=await load('diag',fs.readFileSync('lib/source-diagnostics.ts','utf8').replace("import {db,read,save} from './storage';","const {db,read,save}=globalThis.__store;"));
const before=console.error;console.error=()=>{};
let controller;const stream=new ReadableStream({start(c){controller=c;c.enqueue(new Uint8Array(8192));}});
let at=Date.now();await d.noteSourceHttp('https://www.tpex.org.tw/openapi/v1/tpex_mainboard_quotes',new Response(stream,{status:302}),Date.now());assert.ok(Date.now()-at<900,'stalled body cancellation and D1 must not block research');controller.close();
let empty;const noBytes=new ReadableStream({start(c){empty=c;}});at=Date.now();await d.noteSourceHttp('https://www.tpex.org.tw/openapi/v1/tpex_mainboard_quotes',new Response(noBytes,{status:302}),Date.now());assert.ok(Date.now()-at<900,'stalled reader and D1 must be bounded');empty.close();console.error=before;
console.log('PASS: owner-only access, expiring diagnostic token, strict Origin, bounded stalled body and D1.');
}finally{fs.rmSync(dir,{recursive:true,force:true})}
