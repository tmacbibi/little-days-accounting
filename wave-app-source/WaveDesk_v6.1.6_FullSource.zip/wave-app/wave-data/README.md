# Official daily backup for 波段工作台 v6.1.6

The production Worker receives redirects from TPEx. A separate GitHub Actions job downloads the official publicly available CSV, attention/warning/disposal registries and corporate-action table using ordinary HTTPS. It does not use an LLM, browser disguise, credentials or a proxy workaround.

The collector and workflow also live in `tmacbibi/little-days-accounting`, in isolated `wave-data/` files and `.github/workflows/update-wave-official.yml`. The bookkeeping application is unchanged. Standard public Ubuntu runners execute at 17:23 and 18:23 Taipei on weekdays; scheduled start time is not guaranteed. The first live run (37775174299) succeeded on 2026-10-08.

The fixed raw GitHub URL is declared in `lib/official-bundle.ts`. The Worker validates the bundle structure, actual quote date, risk registry date, corporate-action date range, OHLC and official provenance. It accepts a quote backup only for the independently confirmed current session. A stale or unavailable backup never becomes tomorrow's data. A dated build seed is retained for temporary download failure.

The collector writes atomically only after all official downloads and date checks pass, and refuses to replace newer data. If announcements lack enough evidence of the requested session, it fails conservatively and preserves the previous file. Examine GitHub Actions logs before changing those gates.

New listing 7856 has only 11 official daily bars as of 2026-10-08. Its short history is collected so the update queue can complete; it remains ineligible for analysis until the existing 65-day requirement is met. The Worker can append a contiguous official TWO OHLC bar only with matching prior close and verified corporate actions; gaps and events still require full history.

Verification: TypeScript and production build; bundle validation/stale-date rejection; contiguous TW/TWO daily bar append and corporate-action/gap rejection; original strategy tests. This repair changes data delivery and update completion, not stock selection or scores.
