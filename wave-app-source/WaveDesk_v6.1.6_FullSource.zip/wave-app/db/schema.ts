import {sqliteTable,text,integer} from 'drizzle-orm/sqlite-core';
export const store=sqliteTable('store',{key:text('key').primaryKey(),value:text('value').notNull(),updated:integer('updated').notNull()});
