declare namespace Cloudflare {
  interface Env {
    DIAGNOSTICS_OWNER_EMAIL?: string;
    DIAGNOSTICS_ADMIN_TOKEN?: string;
    DIAGNOSTICS_ADMIN_EXPIRES?: string;
    DB?: D1Database;
    BUCKET?: R2Bucket;
  }
}
